import tkinter as tk
from tkinter import ttk
from tkinter import *
from PIL import Image,ImageTk
import webbrowser
from tkinter import messagebox
import string
import random
import smtplib
from email.mime.text import MIMEText
from tkVideoPlayer import TkinterVideo
from tkvideo import tkvideo
import json
import pandas as pd
import numpy as np
import oauth2client as oauth2client
import gspread
from oauth2client.service_account import ServiceAccountCredentials


def loopVideo(event):
    videoplayer.play()
def pausevideo():
    videoplayer.pause()
def video():
    global videoplayer
    videoplayer = TkinterVideo(master=win1, scaled=True)
    videoplayer.load(r"./Server/Images/Squares.mp4")
    videoplayer.pack(expand=True, fill="both")
    videoplayer.play()
    videoplayer.bind('<<Ended>>', loopVideo)
def get_database():
    global df
    global sheet
    scope = ['https://spreadsheets.google.com/feeds','https://www.googleapis.com/auth/drive']
    # add credentials to the account
    creds = ServiceAccountCredentials.from_json_keyfile_name('./Server/Database/my-gmail-project-201819-cc76151fac85.json', scope)
    # authorize the clientsheet
    client = gspread.authorize(creds)
    # get the instance of the Spreadsheet
    sheet = client.open('Mail_System').sheet1
    data_instance = sheet.get_all_records()
    df = pd.DataFrame.from_dict(data_instance)
get_database()
def username_availability():
    global userfound
    row_index = np.where(df["username"] == str(text1.get()))
    index_no = row_index[0]
    userfound = True
    try:
        val = index_no[0]
    except IndexError:
        userfound = False
def email_availability():
    global emailfound
    row_index = np.where(df["email"] == text4.get())
    index_no = row_index[0]
    emailfound = True
    try:
        val = index_no[0]
    except IndexError:
        emailfound = False
def special_character():
    global special
    special = []
    for i in range(32,48):
        special.append(chr(i))
    for i in range(58,65):
        special.append(chr(i))
    for i in range(91,97):
        special.append(chr(i))
    for i in range(123,127):
        special.append(chr(i))
special_character()
def uppercase():
    global uppercase_letters
    uppercase_letters = []
    for i in range(65,91):
        uppercase_letters.append(chr(i))
uppercase()
def lowercase():
    global lowercase_letters
    lowercase_letters = []
    for i in range(97,123):
        lowercase_letters.append(chr(i))
lowercase()
def digits():
    global numbers
    numbers = []
    for i in range(0,10):
        numbers.append(str(i))
digits()
def check_length():
    global length_result
    length_result = False
    if len(text7.get())>= 8 and len(text7.get())<=24:
        length_result = True
    else:
        length_result = False
        messagebox.showerror("Password Error!", "Password should be '8-24' character long.\n")
def check_special():
    global special_result
    special_result = False
    for i in special:
        if i not in text7.get():
            special_result = False
            continue
        else:
            special_result = True
            break
    if special_result == False:
        messagebox.showerror("Password Error!", "Password should contain special characters.\n")
def check_numeric():
    global numeric_result
    numeric_result = False
    for i in numbers:
        if i not in text7.get():
            numeric_result = False
            continue
        else:
            numeric_result = True
            break
    if numeric_result == False:
        messagebox.showerror("Password Error!", "Password should contain numeric digit also.\n")

def check_lowercase():
    global lowercase_result
    lowercase_result = False
    for i in lowercase_letters:
        if i not in text7.get():
            lowercase_result = False
            continue
        else:
            lowercase_result = True
            break
    if lowercase_result == False:
        messagebox.showerror("Password Error!", "Password should contain lowercase character also.\n")
def check_uppercase():
    global uppercase_result
    uppercase_result = False
    for i in uppercase_letters:
        if i not in text7.get():
            uppercase_result = False
            continue
        else:
            uppercase_result = True
            break
    if uppercase_result == False:
        messagebox.showerror("Password Error!", "Password should contain UPPERCASE character also.\n")
def verify_password():
    global password_result
    password_result = False
    if text6.get() == text7.get():
        check_length()
        if length_result == True:
            check_special()
            if special_result == True:
                check_numeric()
                if numeric_result == True:
                    check_lowercase()
                    if lowercase_result == True:
                        check_uppercase()
                        if uppercase_result == True:
                            password_result = True
    else:
        password_result = False
        messagebox.showerror("Password Error!", "Passwords doesn't match.\nRe-Enter Password.")

def verify_username():
    global username_result
    username_result = False
    if len(str(text1.get())) <= 3 or len(str(text1.get())) > 16:
        messagebox.showerror("Username Error!", "Username should be '4-16' character long.\n")
    else:
        username_result = True
        for i in str(text1.get()):
            if i in special:
                messagebox.showerror("Username Error!", "Remove Special Characters.\n")
                username_result = False
                break
    if username_result == True:
        username_availability()
        if userfound == False:
            username_result = True
        else:
            username_result = False
            messagebox.showerror("Username Error!", "Username already Exist. Try Another!\n")
def verify_names():
    global name_result
    name_result = False
    name_length = len(str(text2.get()))+len(str(text3.get()))
    if name_length >= 1 and name_length <= 32:
        name_result = True
    else:
        messagebox.showerror("Name Error!", "Full Name should be '1-32' character long.\n")
def verify_email():
    global email_result
    email_result = False
    if '@' in text4.get() and '.com' in text4.get():
        email_result = True
    else:
        messagebox.showerror("E-Mail Error!", "Invalid E-Mail address.\n")
    if email_result == True:
        email_availability()
        if emailfound == False:
            email_result = True
        else:
            email_result = False
            email_error = "E-Mail already Exist!\nTry to Sign-Up with different E-Mail."
            messagebox.showerror("E-Mail Error!",email_error )
def verify_mobile():
    global mobile_result
    mobile_result = False
    mobile_str = text5.get()
    if len(mobile_str) == 10 and int(mobile_str[0]) > 5:
        mobile_result = True
    else:
        mobile_result = False
        messagebox.showerror("Mobile No. Error!", "Invalid Mobile No. !")

def gen_captcha():
    global captcha
    len_captcha = 6
    captcha = ''.join(random.choices(('#@$&=#@$&=#@$&=') + string.ascii_letters + string.digits, k=len_captcha))
    global label12
    label12 = Label(win1,text=captcha,relief=RIDGE,bg='black',fg='white',borderwidth=2,width=13,height=1)
    label12.config(font=('georgia', 15,'bold'))
    label12.place(x = 650,y=390)
def verify_captcha():
    inp_captcha = text8.get()
    global captcha_result
    captcha_result = False
    if inp_captcha == captcha:
        captcha_result = True
    else:
        captcha_result = False
        messagebox.showerror("Captcha Error!", "Invalid Captcha!")
        label12.destroy()
        gen_captcha()
def verify_login_captcha():
    inp_captcha1 = text12.get()
    global captcha_result1
    captcha_result1 = False
    if inp_captcha1 == captcha:
        captcha_result1 = True
    else:
        captcha_result1 = False
        messagebox.showerror("Captcha Error!", "Invalid Captcha!")
        gen_captcha()
def verify_gender():
    global gender_result
    gender_result = False
    global sex
    if CheckVar1.get() == 1 or CheckVar2.get() == 1 or CheckVar3.get() == 1:
        gender_result = True
        if CheckVar1.get() == 1:
            sex = 'Male'
        elif CheckVar2.get() == 1:
            sex = 'Female'
        elif CheckVar3.get() == 1:
            sex = 'Others'
    else:
        gender_result = False
        messagebox.showerror("Gender Error!", "Select Gender!")
def verify_two_factor():
    global two_factor
    if CheckVar4.get() == 1:
        two_factor = 'YES'
    elif CheckVar5.get() == 1:
        two_factor = 'NO'
def append_user_signup_data():
    global userdata_list
    userdata_list = []
    userdata_list.append(str(text1.get()))
    userdata_list.append(text7.get())
    userdata_list.append(str(text2.get()))
    userdata_list.append(str(text3.get()))
    userdata_list.append(text4.get())
    userdata_list.append(text5.get())
    userdata_list.append(sex)
    userdata_list.append(two_factor)
def verify_data():
    global data_verified
    data_verified = False
    verify_username()
    if username_result == True:
        verify_names()
        if  name_result  ==  True:
            verify_email()
            if email_result == True:
                verify_mobile()
                if mobile_result == True:
                    verify_password()
                    if password_result == True:
                        verify_captcha()
                        if captcha_result == True:
                            verify_gender()
                            if gender_result == True:
                                data_verified = True
                                verify_two_factor()
                                append_user_signup_data()
                                destroy_signup()
                                otp()
    print(data_verified)
def verify_login_credentials():
    global login_status
    login_status = False
    global userdata
    global username_list
    username_list = df['username'].values.tolist()
    if str(text10.get()) not in username_list:
        login_status = False
        usernotfound = str(text10.get())
        strfornotfound = "'"+usernotfound+"'"+"\nUser doesn't exist.\nTry Again! with valid Username"
        messagebox.showerror("Invalid Username!", strfornotfound)
    else:
        user_info = df[['username', 'password']][df['username'] == str(text10.get())]
        if user_info['password'].values[0] == text11.get():
            verify_login_captcha()
            if captcha_result1 == True:
                login_status = True
                attributes_list = ['username', 'password', 'first_name', 'last_name', 'email', 'mobile_no', 'gender',
                                   'two_factor', 'content']
                user_data = df[attributes_list][df['username'] == str(text10.get())]
                df_to_list = user_data.values.tolist()
                userdata = df_to_list[0]
                after_login()
            else:
                login_status = False
        else:
            login_status = False
            messagebox.showerror("Incorrect Credentials!", "Wrong Username/Password\nTry Again!!!")

def verify_reset_password():
    global data_verified
    data_verified = False
    verify_password()
    if password_result == True:
        verify_captcha()
        if captcha_result == True:
            row_index = np.where(df["username"] == userdata[0])
            row_no = int(row_index[0][0] + 2)
            column_no = int(df.columns.get_loc('password') + 1)
            new_password = str(text7.get())
            sheet.update_cell(row_no, column_no, new_password)
            get_database()
            destroy_change_password()
def dashboard():
    if login_verified == True:
        generate_mail_login()
        dashname_str1 = userdata[2] + ' ' + userdata[3]
        str_login = 'Hi ' + dashname_str1 + ',\nCredentials Matched Succesfully.\nWelcome to "DropMyMail".'
        messagebox.showinfo("Successfully Log-In", str_login)
    else:
        messagebox.showinfo("Log-In 2", 'twofactor = NO')

def after_login():
    destroy_login()
    global login_verified
    login_verified = False
    if userdata[7] == 'YES':
        otp_for_login()
    else:
        login_verified = True
        dashboard()
def generate_mail_signup():
    server = smtplib.SMTP('smtp.gmail.com',587)
    server.starttls()
    server.ehlo()
    server.login('dropmymail.otp@gmail.com','ohinayvuupcykjmy')
    msg = 'Dear '+str(userdata_list[2])+' '+str(userdata_list[3])+',\n\n' \
          'Welcome to DropMyMail,\n\n' \
          "We're thrilled to have you on board as a new user of DropMyMail.\n" \
          "We're confident that our application will provide you with a unique and enjoyable experience.\n\n" \
          'At DropMyMail, our goal is to help you to \n' \
          'broadcast your message/mail to your friend,colleague,team or group by hiding your identity. \n' \
          'Our platform is designed to make it easy and convenient for you to Drop Your Mail to your Target.\n\n' \
          'If you have any questions or need help getting started, our support team is always available to assist you.\n' \
          'You can reach us by email at: dropmymail.otp@gmail.com or through our website: www.vashishthahari.weebly.com\n\n' \
          '\n' \
          "We're looking forward to helping you achieve your goals with DropMyMail.\n" \
          '\n' \
          '\n' \
          '\n' \
          'Best regards,\n' \
          '\n' \
          'The DropMyMail Team,\n' \
          'Harishankar Vashishtha, Developer & Designer\n' \
          'Contact: www.vashishthahari.weebly.com\n' \
          'Email: dropmymail.otp@gmail.com\n' \
          '\n' \
          '\n' \
          'Follow us & spread the word:\n' \
          'Twitter: www.twitter.com/vashishthahari\n' \
          'Facebook: www.facebook.com/vashishthahari\n' \
          'Intagram: www.instagram.com/vashishthahari\n'

    msg1 = MIMEText(msg)
    msg1['Subject'] = 'Account Created Successfully! Welcome '+ userdata_list[2]+' '+userdata_list[3]+' :)'
    server.sendmail('dropmymail.otp@gmail.com',userdata_list[4],msg1.as_string())
    server.quit()

def generate_mail_login():
    server = smtplib.SMTP('smtp.gmail.com', 587)
    server.starttls()
    server.ehlo()
    server.login('dropmymail.otp@gmail.com', 'ohinayvuupcykjmy')
    msg = 'Dear '+str(userdata[2])+' '+str(userdata[3])+',\n\n' \
          "We're glad to see you back on DropMyMail\n" \
          "We hope you're finding our application to be a valuable tool to broadcast your message/mail to your group or individual.\n" \
          '\n' \
          "If there's anything we can help with or if you have any questions, don't hesitate to \n" \
          'reach out to our support team at dropmymail.otp@gmail.com or through our website www.vashishthahari.weebly.com\n\n' \
          'In the meantime, here are a few updates and features you may have missed since your last visit:\n' \
          '=> Bug Fixed\n' \
          '=> Dual Factor authentication introduced\n' \
          '=> Password Reset Enabled\n' \
          '\n' \
          "Thank you for choosing DropMyMail. We're dedicated to providing you with the best experience possible.\n" \
          '\n' \
          '\n' \
          '\n' \
          'Best regards,\n' \
          '\n' \
          'The DropMyMail Team,\n' \
          'Harishankar Vashishtha, Developer & Designer\n' \
          'Contact: www.vashishthahari.weebly.com\n' \
          'Email: dropmymail.otp@gmail.com\n' \
          '\n' \
          '\n' \
          'Follow us & spread the word:\n' \
          'Twitter: www.twitter.com/vashishthahari\n' \
          'Facebook: www.facebook.com/vashishthahari\n' \
          'Intagram: www.instagram.com/vashishthahari\n' \

    msg1 = MIMEText(msg)
    msg1['Subject'] = 'Log-In Detected! Welcome '+ userdata[2]+' '+userdata[3]+' :)'
    server.sendmail('dropmymail.otp@gmail.com', userdata[4], msg1.as_string())
    server.quit()
def generate_mail_reset():
    server = smtplib.SMTP('smtp.gmail.com', 587)
    server.starttls()
    server.ehlo()
    server.login('dropmymail.otp@gmail.com', 'ohinayvuupcykjmy')
    msg = 'Dear '+str(userdata[2])+' '+str(userdata[3])+',\n\n' \
          "You successfully resetted your Password.\n" \
          "We hope you're finding our application to be a valuable tool to broadcast your message/mail to your group or individual.\n" \
          '\n' \
          "If there's anything we can help with or if you have any questions, don't hesitate to \n" \
          'reach out to our support team at dropmymail.otp@gmail.com or through our website www.vashishthahari.weebly.com\n\n' \
          'In the meantime, here are a few updates and features you may have missed since your last visit:\n' \
          '=> Bug Fixed\n' \
          '=> Dual Factor authentication introduced\n' \
          '=> Password Reset Enabled\n' \
          '\n' \
          "Thank you for choosing DropMyMail. We're dedicated to providing you with the best experience possible.\n" \
          '\n' \
          '\n' \
          '\n' \
          'Best regards,\n' \
          '\n' \
          'The DropMyMail Team,\n' \
          'Harishankar Vashishtha, Developer & Designer\n' \
          'Contact: www.vashishthahari.weebly.com\n' \
          'Email: dropmymail.otp@gmail.com\n' \
          '\n' \
          '\n' \
          'Follow us & spread the word:\n' \
          'Twitter: www.twitter.com/vashishthahari\n' \
          'Facebook: www.facebook.com/vashishthahari\n' \
          'Intagram: www.instagram.com/vashishthahari\n' \

    msg1 = MIMEText(msg)
    msg1['Subject'] = 'Password Resetted Successfully! You can now Log-In :) Username: '+userdata[0]
    server.sendmail('dropmymail.otp@gmail.com', userdata[4], msg1.as_string())
    server.quit()
def generate_otp():
    global email
    global OTP
    resend = False
    otp_generated = True
    server = smtplib.SMTP('smtp.gmail.com',587)
    server.starttls()
    server.ehlo()
    server.login('dropmymail.otp@gmail.com','ohinayvuupcykjmy')
    OTP = ''.join([str(random.randint(0,9)) for i in range(6)])
    #msg = f'Hello {userdata_list[2]} {userdata_list[3]},\nYour OTP for Login Verification is {OTP}'
    msg = 'Dear '+str(userdata_list[2])+' '+str(userdata_list[3])+',\n' \
           '\n' \
           'Here is the OTP you requested to Create Account on DropMyMail: '+str(OTP)+ '\n'\
           '\n' \
           '\n' \
           'Username: '+str(userdata_list[0])+ '\n'\
           'If you did not initiate this request, please ignore the message. \n' \
           "It's often a good security measure to change your password and avoid using the same password on several accounts.\n\n" \
           "Why did you receive this notification?\n" \
           "It's possible another user entered your email address or username by mistake.\n" \
           'If you have a company account, you might want to check if one of your colleagues reset the password.\n' \
           '\n' \
           '\n' \
           '\n' \
           'The DropMyMail Team,\n' \
           'Harishankar Vashishtha, Developer & Designer\n' \
           'Contact: www.vashishthahari.weebly.com\n' \
           'Email: dropmymail.otp@gmail.com\n' \
           '\n' \
           '\n' \
           'Follow us & spread the word:\n' \
           'Twitter: www.twitter.com/vashishthahari\n' \
           'Facebook: www.facebook.com/vashishthahari\n' \
           'Intagram: www.instagram.com/vashishthahari\n'

    msg1 = MIMEText(msg)
    msg1['Subject'] = 'OTP to Create New Account! :) Username: '+userdata_list[0]
    server.sendmail('dropmymail.otp@gmail.com',userdata_list[4],msg1.as_string())
    server.quit()
    label20.destroy()
    # global label21
    # label21 = Button(win1, text='Re-Send OTP',relief=RAISED, bg='#00FFFF',borderwidth=5,command=resend_otp)
    # label21.config(font=('georgia', 14, 'bold'))
    # label21.place(x=340, y=306)
def generate_otp_for_login():
    global email
    global OTP
    resend = False
    otp_generated = True
    server = smtplib.SMTP('smtp.gmail.com',587)
    server.starttls()
    server.ehlo()
    server.login('dropmymail.otp@gmail.com','ohinayvuupcykjmy')
    OTP = ''.join([str(random.randint(0,9)) for i in range(6)])
    #msg = f'Hello {userdata[2]} {userdata[3]},\nYour OTP for Login Verification is {OTP}'
    msg = 'Dear '+str(userdata[2])+' '+str(userdata[3])+',\n' \
           '\n' \
           'Here is the OTP you requested for Two-Factor Authentication: '+str(OTP)+ '\n'\
           '\n' \
           '\n' \
           'Username: '+str(userdata[0])+ '\n'\
           'If you did not initiate this request, please ignore the message. \n' \
           "It's often a good security measure to change your password and avoid using the same password on several accounts.\n" \
           "Why did you receive this notification?\n" \
           "It's possible another user entered your email address or username by mistake.\n" \
           'If you have a company account, you might want to check if one of your colleagues reset the password.\n' \
           '\n' \
           '\n' \
           '\n' \
           'The DropMyMail Team,\n' \
           'Harishankar Vashishtha, Developer & Designer\n' \
           'Contact: www.vashishthahari.weebly.com\n' \
           'Email: dropmymail.otp@gmail.com\n' \
           '\n' \
           '\n' \
           'Follow us & spread the word:\n' \
           'Twitter: www.twitter.com/vashishthahari\n' \
           'Facebook: www.facebook.com/vashishthahari\n' \
           'Intagram: www.instagram.com/vashishthahari\n'

    msg1 = MIMEText(msg)
    msg1['Subject'] = 'OTP for Two-Factor Authentication Log-In! :) Username: '+userdata[0]
    server.sendmail('dropmymail.otp@gmail.com',userdata[4],msg1.as_string())
    server.quit()
    label20.destroy()
    # global label21
    # label21 = Button(win1, text='Re-Send OTP',relief=RAISED, bg='#00FFFF',borderwidth=5,command=resend_otp)
    # label21.config(font=('georgia', 14, 'bold'))
    # label21.place(x=340, y=306)
def generate_otp_for_reset():
    global email
    global OTP
    resend = False
    otp_generated = True
    server = smtplib.SMTP('smtp.gmail.com',587)
    server.starttls()
    server.ehlo()
    server.login('dropmymail.otp@gmail.com','ohinayvuupcykjmy')
    OTP = ''.join([str(random.randint(0,9)) for i in range(6)])
    #msg = f'Hello {userdata[2]} {userdata[3]},\nYour OTP for Login Verification is {OTP}'
    msg = 'Dear '+str(userdata[2])+' '+str(userdata[3])+',\n' \
           '\n' \
           'Here is the OTP you requested to Reset your Password: '+str(OTP)+ '\n'\
           '\n' \
           '\n' \
           'Username: '+str(userdata[0])+ '\n'\
           'If you did not initiate this request, please ignore the message. \n' \
           "It's often a good security measure to change your password and avoid using the same password on several accounts.\n" \
           "Why did you receive this notification?\n" \
           "It's possible another user entered your email address or username by mistake.\n" \
           'If you have a company account, you might want to check if one of your colleagues reset the password.\n' \
           '\n' \
           '\n' \
           '\n' \
           'The DropMyMail Team,\n' \
           'Harishankar Vashishtha, Developer & Designer\n' \
           'Contact: www.vashishthahari.weebly.com\n' \
           'Email: dropmymail.otp@gmail.com\n' \
           '\n' \
           '\n' \
           'Follow us & spread the word:\n' \
           'Twitter: www.twitter.com/vashishthahari\n' \
           'Facebook: www.facebook.com/vashishthahari\n' \
           'Intagram: www.instagram.com/vashishthahari\n'

    msg1 = MIMEText(msg)
    msg1['Subject'] = 'OTP to Reset your Password! :) Username: '+userdata[0]
    server.sendmail('dropmymail.otp@gmail.com',userdata[4],msg1.as_string())
    server.quit()
    label20.destroy()
    # global label21
    # label21 = Button(win1, text='Re-Send OTP',relief=RAISED, bg='#00FFFF',borderwidth=5,command=resend_otp)
    # label21.config(font=('georgia', 14, 'bold'))
    # label21.place(x=340, y=306)

def resend_otp():
    resend = True
    global OTP
    server = smtplib.SMTP('smtp.gmail.com',587)
    server.starttls()
    server.login('dropmymail.otp@gmail.com','ohinayvuupcykjmy')
    OTP = ''.join([str(random.randint(0,9)) for i in range(6)])
    msg = f'Hello {userdata_list[2]}  {userdata_list[3]}, Your New OTP for Verification is {OTP}'
    server.sendmail('dropmymail.otp@gmail.com',userdata_list[4],msg)
    server.quit()
    #label21.destroy()
def login_otp_verification():
    otp_input = text9.get()
    global login_verified
    if otp_input == OTP:
        login_verified = True
        label18.destroy(),text9.destroy(),label19.destroy(),label22.destroy(),label23.destroy(),label24.destroy()
        label25.destroy(),label26.destroy(),label27.destroy(),label28.destroy()
        dashboard()
        # otp_msg_str = "Congratulations! " + userdata[2] + ' ' + userdata[3] + "\nOTP Verified."
        # messagebox.showinfo("OTP Verified", otp_msg_str)
    else:
        messagebox.showwarning("Error!", 'Invalid OTP!')
def reset_otp_verification():
    otp_input = text9.get()
    global login_verified
    if otp_input == OTP:
        login_verified = True
        label18.destroy(),text9.destroy(),label19.destroy(),label22.destroy(),label23.destroy(),label24.destroy()
        label25.destroy(),label26.destroy(),label27.destroy(),label28.destroy()
        otp_msg_str = "" + userdata[2] + ' ' + userdata[3] + "" \
                      "\nOTP Verified.\nNow you can create your new password for your account.\nUsername: '"+userdata[0]+"'"
        messagebox.showinfo("OTP Verified", otp_msg_str)
        change_password()
    else:
        messagebox.showwarning("Error!", 'Invalid OTP!')
def otp_verification():
    global append_status
    global otp_input
    otp_input = text9.get()
    if  otp_input == OTP:
        #destroy_otp()
        # sheet.insert_row(userdata_list, 2)
        # get_database()
        label22.destroy()
        otp_verified()
        append_status = True
    else:
        messagebox.showwarning("Error!", 'Invalid OTP!')
def disable_female_other_check():
    if CheckVar1.get() == 1:
        check2.deselect()
        check3.deselect()
    elif CheckVar1.get() == 0:
        check2.deselect()
        check3.deselect()
def disable_other_male_check():
    if CheckVar2.get() == 1:
        check3.deselect()
        check1.deselect()
    elif CheckVar2.get() == 0:
        check1.deselect()
        check3.deselect()
def disable_male_female_check():
    if CheckVar3.get() == 1:
        check1.deselect()
        check2.deselect()
    elif CheckVar3.get() == 0:
        check1.deselect()
        check2.deselect()
def enable_security_check():
    if CheckVar4.get() == 1:
        check5.deselect()
    elif CheckVar4.get() == 0:
        check5.select()
def disable_security_check():
    if CheckVar5.get() == 1:
        check4.deselect()
    elif CheckVar5.get() == 0:
        check4.select()

def win1():
    global win1
    win1 = tk.Tk()
    win1.iconbitmap("./Server/Images/ww.ico")
    win1.title('DropMyMail')
    win1.geometry('1279x650')
    video()
    #change_password()
    #forgot_password()
    signup()
    #otp()
    #login()
    win1.mainloop()

def destroy_signup():
    videoplayer.destroy()
    label2.destroy(),label3.destroy(),label4.destroy(),label5.destroy(),label6.destroy()
    label7.destroy(), label8.destroy(), label9.destroy(), label10.destroy(), label11.destroy()
    label12.destroy(),label13.destroy(), label14.destroy(), label15.destroy(), label16.destroy()
    label17.destroy()
    text1.destroy(),text2.destroy(),text3.destroy(),text4.destroy(),text5.destroy()
    text6.destroy(), text7.destroy(), text8.destroy()
    check1.destroy(),check2.destroy(),check3.destroy(),check4.destroy(),check5.destroy()
    video()
def otp_previous_clicked():
    global previous_click
    previous_click = True
    destroy_otp()
    signup()
def login_signup_clicked():
    destroy_login()
    signup()
def signup_login_clicked():
    destroy_signup()
    login()
def otp_verified_login_clicked():
    label29.destroy(),label44.destroy(),label23.destroy(),label24.destroy()
    label25.destroy(),label26.destroy(),label27.destroy(),label28.destroy()
    login()
def otp_verified():
    label19.destroy(),text9.destroy(),label22.destroy()
    # if resend == False:
    #     label21.destroy()
    sheet.insert_row(userdata_list, 2)
    get_database()
    generate_mail_signup()
    otp_msg_str = "Congratulations! "+userdata_list[2]+' '+userdata_list[3]+"\nOTP Verified.\nAccount Created Succesfully\nYou can now Log-In."
    messagebox.showinfo("OTP Verified", otp_msg_str)

    global label44
    name_str = userdata_list[2]+' '+userdata_list[3]
    str_login = 'Hi '+name_str+',\nYour Account Created Succesfully.\nClick below to Log-In.'
    label44 = Label(win1,text=str_login, bg="#00FA9A",fg='blue')
    label44.config(font=('georgia', 20, 'bold'))
    label44.place(x=400, y=250)

    global label29
    img29 = Image.open('./Server/Images/login.png')
    resize29 = img29.resize((176, 54))
    img_29 = ImageTk.PhotoImage(resize29)
    label29 = Button(win1, image=img_29, relief=FLAT, bg='#00FA9A', bd=0, activebackground='#00FA9A',command=otp_verified_login_clicked)
    label29.place(x=560, y=370)

    win1.mainloop()
def password_changed():
    generate_mail_reset()


    global label18
    label18 = Label(win1, bg="#00FA9A", relief=RIDGE, borderwidth=10, width=95, height=38)
    label18.place(x=292, y=30)

    global label23
    label23 = Label(win1, text='Two-Factor Authentication', bg='#00FA9A', fg='blue')
    label23.config(font=('times new roman', 30, 'underline'))
    label23.place(x=420, y=70)

    global label24
    img24 = Image.open('./Server/Images/twofact.png')
    resize24 = img24.resize((80, 80))
    img_24 = ImageTk.PhotoImage(resize24)
    label24 = Label(win1, image=img_24, bg='#00FA9A', bd=0)
    label24.place(x=335, y=60)

    global label25
    img25 = Image.open('./Server/Images/twofact.png')
    resize25 = img25.resize((80, 80))
    img_25 = ImageTk.PhotoImage(resize25)
    label25 = Label(win1, image=img_25, bg='#00FA9A', bd=0)
    label25.place(x=860, y=60)

    global label26
    img26 = Image.open('./Server/Images/ww.png')
    resize26 = img26.resize((80, 80))
    img_26 = ImageTk.PhotoImage(resize26)
    label26 = Label(win1, image=img_26, bg="#00FA9A", bd=0)
    label26.place(x=600, y=130)

    otp_msg_str = "Hi "+userdata[2]+' '+userdata[3]+"\nYou successfully resetted your password .\nYou can now login using your new password."
    messagebox.showinfo("Password Changed", otp_msg_str)

    global label44
    name_str = userdata[2]+' '+userdata[3]
    str_login = 'Hi '+name_str+',\nYour Password Changed Succesfully.\nClick below to Log-In.'
    label44 = Label(win1,text=str_login, bg="#00FA9A",fg='blue')
    label44.config(font=('georgia', 20, 'bold'))
    label44.place(x=400, y=250)

    global label29
    img29 = Image.open('./Server/Images/login.png')
    resize29 = img29.resize((176, 54))
    img_29 = ImageTk.PhotoImage(resize29)
    label29 = Button(win1, image=img_29, relief=FLAT, bg='#00FA9A', bd=0, activebackground='#00FA9A',command=otp_verified_login_clicked)
    label29.place(x=560, y=370)

    win1.mainloop()


def destroy_otp():
    label18.destroy(),label19.destroy(),text9.destroy(),label22.destroy()
    label23.destroy(),label24.destroy(),label25.destroy(),label26.destroy()
    label27.destroy(),label28.destroy()
    # if resend == False and otp_generated == True:
    #     label21.destroy()
    if otp_generated == False:
        label20.destroy()
    # videoplayer.destroy()
    # video()
def destroy_login():
    label30.destroy(),label31.destroy(),label32.destroy(),label35.destroy(),label36.destroy()
    label37.destroy(), label38.destroy(), label39.destroy(), label40.destroy(), label41.destroy()
    label42.destroy(), label43.destroy(), text10.destroy(), text11.destroy(), text12.destroy()
    videoplayer.destroy()
    video()
def destroy_otp_for_login():
    label18.destroy(),label19.destroy(),text9.destroy(),label20.destroy(),label22.destroy()
    label23.destroy(),label24.destroy(),label25.destroy(),label26.destroy(),label27.destroy()
    label28.destroy()
    login()
def destroy_forgot_password():
    label18.destroy(),text9.destroy(),label22.destroy(),label23.destroy(),label24.destroy(),label25.destroy()
    label26.destroy(),check4.destroy(),check5.destroy()
    videoplayer.destroy()
    video()
def destroy_change_password():
    label18.destroy(), label23.destroy(), label26.destroy(), label6.destroy(), text6.destroy()
    label8.destroy(), text7.destroy(), label11.destroy(), text8.destroy(),
    label13.destroy(),label14.destroy(),label15.destroy()
    videoplayer.destroy()
    video()
    password_changed()

def otp_for_login():
    global otp_generated
    otp_generated = False
    global label18
    label18 = Label(win1, bg="#00FA9A", relief=RIDGE, borderwidth=10, width=95, height=38)
    label18.place(x=292, y=30)

    global label19
    email_str = 'E-Mail: ' + userdata[4]
    label19 = Label(win1, text=email_str, bg='#00FA9A')
    label19.config(font=('georgia', 15, 'bold'))
    label19.place(x=340, y=230)
    global text9
    text9 = tk.Entry(master=win1, width=25, relief=RIDGE, borderwidth=5)
    text9.config(font=('times new roman', 17))
    text9.place(x=340, y=262)
    text9.focus_set()

    global label20
    label20 = Button(win1, text='Send OTP', relief=RAISED, bg='#FFD700', borderwidth=5, command=generate_otp_for_login)
    label20.config(font=('georgia', 14, 'bold'))
    label20.place(x=340, y=306)

    global label22
    label22 = Button(win1, text='Verify OTP', relief=RAISED, bg='#FF4500', borderwidth=5, command=login_otp_verification)
    label22.config(font=('georgia', 14, 'bold'))
    label22.place(x=494, y=306)

    global label23
    label23 = Label(win1, text='Two-Factor Authentication', bg='#00FA9A', fg='blue')
    label23.config(font=('times new roman', 30, 'underline'))
    label23.place(x=420, y=70)

    global label24
    img24 = Image.open('./Server/Images/twofact.png')
    resize24 = img24.resize((80, 80))
    img_24 = ImageTk.PhotoImage(resize24)
    label24 = Label(win1, image=img_24, bg='#00FA9A', bd=0)
    label24.place(x=335, y=60)

    global label25
    img25 = Image.open('./Server/Images/twofact.png')
    resize25 = img25.resize((80, 80))
    img_25 = ImageTk.PhotoImage(resize25)
    label25 = Label(win1, image=img_25, bg='#00FA9A', bd=0)
    label25.place(x=860, y=60)

    global label26
    img26 = Image.open('./Server/Images/ww.png')
    resize26 = img26.resize((80, 80))
    img_26 = ImageTk.PhotoImage(resize26)
    label26 = Label(win1, image=img_26, bg="#00FA9A", bd=0)
    label26.place(x=600, y=130)

    global label27
    img27 = Image.open('./Server/Images/previous.png')
    resize27 = img27.resize((80, 80))
    img_27 = ImageTk.PhotoImage(resize27)
    label27 = Button(win1, image=img_27, bg="#00FA9A", bd=0, activebackground='#00FA9A', command=destroy_otp_for_login)
    label27.place(x=320, y=520)

    global label28
    img28 = Image.open('./Server/Images/next.png')
    resize28 = img28.resize((80, 80))
    img_28 = ImageTk.PhotoImage(resize28)
    label28 = Button(win1, image=img_28, bg="#00FA9A", bd=0, activebackground='#00FA9A')
    label28.place(x=875, y=520)

    win1.mainloop()

def otp_for_reset():
    global otp_generated
    otp_generated = False
    global label18
    label18 = Label(win1, bg="#00FA9A", relief=RIDGE, borderwidth=10, width=95, height=38)
    label18.place(x=292, y=30)

    global label19
    email_str = 'E-Mail: ' + userdata[4]
    label19 = Label(win1, text=email_str, bg='#00FA9A')
    label19.config(font=('georgia', 15, 'bold'))
    label19.place(x=340, y=230)
    global text9
    text9 = tk.Entry(master=win1, width=25, relief=RIDGE, borderwidth=5)
    text9.config(font=('times new roman', 17))
    text9.place(x=340, y=262)
    text9.focus_set()

    global label20
    label20 = Button(win1, text='Send OTP', relief=RAISED, bg='#FFD700', borderwidth=5, command=generate_otp_for_reset)
    label20.config(font=('georgia', 14, 'bold'))
    label20.place(x=340, y=306)

    global label22
    label22 = Button(win1, text='Verify OTP', relief=RAISED, bg='#FF4500', borderwidth=5, command=reset_otp_verification)
    label22.config(font=('georgia', 14, 'bold'))
    label22.place(x=494, y=306)

    global label23
    label23 = Label(win1, text='Two-Factor Authentication', bg='#00FA9A', fg='blue')
    label23.config(font=('times new roman', 30, 'underline'))
    label23.place(x=420, y=70)

    global label24
    img24 = Image.open('./Server/Images/twofact.png')
    resize24 = img24.resize((80, 80))
    img_24 = ImageTk.PhotoImage(resize24)
    label24 = Label(win1, image=img_24, bg='#00FA9A', bd=0)
    label24.place(x=335, y=60)

    global label25
    img25 = Image.open('./Server/Images/twofact.png')
    resize25 = img25.resize((80, 80))
    img_25 = ImageTk.PhotoImage(resize25)
    label25 = Label(win1, image=img_25, bg='#00FA9A', bd=0)
    label25.place(x=860, y=60)

    global label26
    img26 = Image.open('./Server/Images/ww.png')
    resize26 = img26.resize((80, 80))
    img_26 = ImageTk.PhotoImage(resize26)
    label26 = Label(win1, image=img_26, bg="#00FA9A", bd=0)
    label26.place(x=600, y=130)

    global label27
    img27 = Image.open('./Server/Images/previous.png')
    resize27 = img27.resize((80, 80))
    img_27 = ImageTk.PhotoImage(resize27)
    label27 = Button(win1, image=img_27, bg="#00FA9A", bd=0, activebackground='#00FA9A', command=destroy_otp_for_login)
    label27.place(x=320, y=520)

    global label28
    img28 = Image.open('./Server/Images/next.png')
    resize28 = img28.resize((80, 80))
    img_28 = ImageTk.PhotoImage(resize28)
    label28 = Button(win1, image=img_28, bg="#00FA9A", bd=0, activebackground='#00FA9A')
    label28.place(x=875, y=520)

    win1.mainloop()
def reset_password():
    global userdata
    global username_list
    if CheckVar4.get() == 1:
        username_list = df['username'].values.tolist()
        if str(text9.get()) not in username_list:
            login_status = False
            usernotfound = str(text9.get())
            strfornotfound = "'" + usernotfound + "'" + "\nUser doesn't exist.\nTry Again! with your Username"
            messagebox.showerror("Invalid Username!", strfornotfound)
        else:
            attributes_list = ['username', 'password', 'first_name', 'last_name', 'email']
            user_data = df[attributes_list][df['username'] == str(text9.get())]
            df_to_list = user_data.values.tolist()
            userdata = df_to_list[0]
            destroy_forgot_password()
            otp_for_reset()
    elif CheckVar5.get() == 1:
        username_list = df['email'].values.tolist()
        if str(text9.get()) not in username_list:
            login_status = False
            usernotfound = str(text9.get())
            strfornotfound = "'" + usernotfound + "'" + "\nE-Mail doesn't exist.\nTry Again! with your registered E-Mail"
            messagebox.showerror("Invalid E-Mail!", strfornotfound)
        else:
            attributes_list = ['username', 'password', 'first_name', 'last_name', 'email']
            user_data = df[attributes_list][df['email'] == str(text9.get())]
            df_to_list = user_data.values.tolist()
            userdata = df_to_list[0]
            destroy_forgot_password()
            otp_for_reset()
def change_password():
    global label18
    label18 = Label(win1, bg="#00FA9A", relief=RIDGE, borderwidth=10, width=95, height=38)
    label18.place(x=292, y=30)

    global label23
    label23 = Label(win1, text='Create New Password', bg='#00FA9A', fg='blue')
    label23.config(font=('times new roman', 30, 'underline'))
    label23.place(x=470, y=70)

    global label26
    img26 = Image.open('./Server/Images/ww.png')
    resize26 = img26.resize((80, 80))
    img_26 = ImageTk.PhotoImage(resize26)
    label26 = Label(win1, image=img_26, bg="#00FA9A", bd=0)
    label26.place(x=600, y=120)


    global label6
    label6 = Label(win1, text='New Password:', bg='#00FA9A')
    label6.config(font=('georgia', 15, 'bold'))
    label6.place(x=340, y=230)
    global text6
    text6 = tk.Entry(master=win1, width=25, show='*',relief=RIDGE,borderwidth=3)
    text6.config(font=('times new roman', 17))
    text6.place(x=340, y=260)

    global label8
    label8 = Label(win1, text='Confirm New Password:', bg='#00FA9A')
    label8.config(font=('georgia', 15, 'bold'))
    label8.place(x=340, y=295)
    global text7
    text7 = tk.Entry(master=win1, width=25,relief=RIDGE,borderwidth=3)
    text7.config(font=('times new roman', 17))
    text7.place(x=340, y=325)


    global label11
    label11 = Label(win1, text='Captcha:', bg='#00FA9A')
    label11.config(font=('georgia', 15, 'bold'))
    label11.place(x=340, y=360)
    global text8
    text8 = tk.Entry(master=win1, width=25,relief=RIDGE,borderwidth=3)
    text8.config(font=('times new roman', 17))
    text8.place(x=340, y=390)
    #captcha = '123456'
    global label14
    label14 = Label(win1, text=captcha, relief=RIDGE, bg='black', fg='white', borderwidth=2, width=13, height=1)
    label14.config(font=('georgia', 15, 'bold'))
    label14.place(x=650, y=390)

    global label13
    img13 = Image.open('./Server/Images/captcha.png')
    resize13 = img13.resize((24, 24))
    img_13 = ImageTk.PhotoImage(resize13)
    label13 = Button(win1, image=img_13, bg="white", command=gen_captcha)
    label13.place(x=838, y=390)

    global label15
    img15 = Image.open('./Server/Images/submit.png')
    resize15 = img15.resize((150, 50))
    img_15 = ImageTk.PhotoImage(resize15)
    label15 = Button(win1, image=img_15, relief=FLAT, bg='#00FA9A', bd=0, activebackground='#00FA9A',command=verify_reset_password)
    label15.place(x=340, y=440)


    win1.mainloop()

def forgot_password():
    global label18
    label18 = Label(win1, bg="#00FA9A", relief=RIDGE, borderwidth=10, width=95, height=38)
    label18.place(x=292, y=30)

    global CheckVar4, CheckVar5
    CheckVar4 = IntVar()
    CheckVar4.set(1)
    CheckVar5 = IntVar()

    global check4, check5
    check4 = Checkbutton(win1, text="Username", bg='#00FA9A', activebackground='#00FA9A', selectcolor='pink',
                         variable=CheckVar4, onvalue=1, offvalue=0, height=1, width=7, command=enable_security_check)
    check4.config(font=('times new roman', 16, 'bold'))
    check4.place(x=338, y=230)
    check5 = Checkbutton(win1, text="E-Mail", bg='#00FA9A', activebackground='#00FA9A', selectcolor='pink',
                         variable=CheckVar5, onvalue=1, offvalue=0, height=1, width=7, command=disable_security_check)
    check5.config(font=('times new roman', 16, 'bold'))
    check5.place(x=520, y=230)

    global text9
    text9 = tk.Entry(master=win1, width=38, relief=RIDGE, borderwidth=5)
    text9.config(font=('times new roman', 17))
    text9.place(x=340, y=262)
    text9.focus_set()

    global label23
    label23 = Label(win1, text='Forgot Password', bg='#00FA9A', fg='blue')
    label23.config(font=('times new roman', 30, 'underline'))
    label23.place(x=500, y=70)

    global label24
    img24 = Image.open('./Server/Images/twofact.png')
    resize24 = img24.resize((80, 80))
    img_24 = ImageTk.PhotoImage(resize24)
    label24 = Label(win1, image=img_24, bg='#00FA9A', bd=0)
    label24.place(x=335, y=60)

    global label25
    img25 = Image.open('./Server/Images/twofact.png')
    resize25 = img25.resize((80, 80))
    img_25 = ImageTk.PhotoImage(resize25)
    label25 = Label(win1, image=img_25, bg='#00FA9A', bd=0)
    label25.place(x=860, y=60)

    global label26
    img26 = Image.open('./Server/Images/ww.png')
    resize26 = img26.resize((80, 80))
    img_26 = ImageTk.PhotoImage(resize26)
    label26 = Label(win1, image=img_26, bg="#00FA9A", bd=0)
    label26.place(x=600, y=120)

    global label22
    label22 = Button(win1, text='Reset Password',relief=RAISED, bg='#FF7F50',borderwidth=5,command=reset_password)
    label22.config(font=('georgia', 14, 'bold'))
    label22.place(x=340, y=306)


    win1.mainloop()

def otp():
    #print(userdata_list)
    global resend
    global otp_generated
    otp_generated = False
    resend = False
    global label18
    label18 = Label(win1, bg="#00FA9A", relief=RIDGE, borderwidth=10, width=95, height=38)
    label18.place(x=292, y=30)


    global label19
    email_str = 'E-Mail: '+ userdata_list[4]
    label19 = Label(win1, text=email_str, bg='#00FA9A')
    label19.config(font=('georgia', 15, 'bold'))
    label19.place(x=340, y=230)
    global text9
    text9 = tk.Entry(master=win1, width=25,relief=RIDGE,borderwidth=5)
    text9.config(font=('times new roman', 17))
    text9.place(x=340, y=262)
    text9.focus_set()
    
    global label20
    label20 = Button(win1, text='Send OTP',relief=RAISED, bg='#FFD700',borderwidth=5,command=generate_otp)
    label20.config(font=('georgia', 14, 'bold'))
    label20.place(x=340, y=306)
    
    global label22
    label22 = Button(win1, text='Verify OTP',relief=RAISED, bg='#FF4500',borderwidth=5,command=otp_verification)
    label22.config(font=('georgia', 14, 'bold'))
    label22.place(x=494, y=306)

    global label23
    label23 = Label(win1, text='Two-Factor Authentication', bg='#00FA9A',fg='blue')
    label23.config(font=('times new roman', 30, 'underline'))
    label23.place(x=420, y=70)
    
    global label24
    img24 = Image.open('./Server/Images/twofact.png')
    resize24 = img24.resize((80,80))
    img_24 = ImageTk.PhotoImage(resize24)
    label24 = Label(win1, image=img_24, bg='#00FA9A',bd=0)
    label24.place(x=335, y=60)
    
    global label25
    img25 = Image.open('./Server/Images/twofact.png')
    resize25 = img25.resize((80, 80))
    img_25 = ImageTk.PhotoImage(resize25)
    label25 = Label(win1, image=img_25, bg='#00FA9A',bd=0)
    label25.place(x=860, y=60)
    

    global label26
    img26 = Image.open('./Server/Images/ww.png')
    resize26 = img26.resize((80, 80))
    img_26 = ImageTk.PhotoImage(resize26)
    label26 = Label(win1, image=img_26,bg="#00FA9A",bd=0)
    label26.place(x = 600,y=130)
    
    global label27
    img27 = Image.open('./Server/Images/previous.png')
    resize27 = img27.resize((80, 80))
    img_27 = ImageTk.PhotoImage(resize27)
    label27 = Button(win1, image=img_27,bg="#00FA9A",bd=0, activebackground='#00FA9A',command=otp_previous_clicked)
    label27.place(x = 320,y=520)
    
    global label28
    img28 = Image.open('./Server/Images/next.png')
    resize28 = img28.resize((80, 80))
    img_28 = ImageTk.PhotoImage(resize28)
    label28 = Button(win1, image=img_28,bg="#00FA9A",bd=0, activebackground='#00FA9A')
    label28.place(x = 875,y=520)

    win1.mainloop()
def login():
    gen_captcha()

    # global label1
    # img1 = Image.open('./Server/Images/logo.jpg')
    # resize1 = img1.resize((50, 50))
    # img_1 = ImageTk.PhotoImage(resize1)
    # label1 = Label(win1, image=img_1,bg="orange")
    # label1.place(x = 614,y=5)

    global label30
    label30 = Label(win1, bg="#00FA9A", relief=RIDGE, borderwidth=10, width=95, height=38)
    label30.place(x=292, y=30)

    global label31
    img31 = Image.open('./Server/Images/login.png')
    resize31 = img31.resize((176, 54))
    img_31 = ImageTk.PhotoImage(resize31)
    label31 = Label(win1, image=img_31, bg='#00FA9A')
    label31.place(x=550, y=43)

    global label32
    label32 = Label(win1, text='USERNAME:', bg='#00FA9A')
    label32.config(font=('georgia', 15, 'bold'))
    label32.place(x=340, y=230)
    global text10
    text10 = tk.Entry(master=win1, width=25,relief=RIDGE,borderwidth=3)
    text10.config(font=('times new roman', 17))
    text10.place(x=340, y=260)
    text10.focus_set()

    global label35
    label35 = Label(win1, text='PASSWORD:', bg='#00FA9A')
    label35.config(font=('georgia', 15, 'bold'))
    label35.place(x=340, y=295)
    global text11
    text11 = tk.Entry(master=win1, width=25,show='*',relief=RIDGE,borderwidth=3)
    text11.config(font=('times new roman', 17))
    text11.place(x=340, y=325)
    
    global label36
    label36 = Label(win1, text='CAPTCHA:', bg='#00FA9A')
    label36.config(font=('georgia', 15, 'bold'))
    label36.place(x=340, y=360)
    global text12
    text12 = tk.Entry(master=win1, width=25,relief=RIDGE,borderwidth=3)
    text12.config(font=('times new roman', 17))
    text12.place(x=340, y=390)
    global label37
    label37 = Label(win1, text=captcha, relief=RIDGE, bg='black', fg='white', borderwidth=2, width=13, height=1)
    label37.config(font=('georgia', 15, 'bold'))
    label37.place(x=650, y=390)

    global label38
    img38 = Image.open('./Server/Images/captcha.png')
    resize38 = img38.resize((24, 24))
    img_38 = ImageTk.PhotoImage(resize38)
    label38 = Button(win1, image=img_38, bg="white", command=gen_captcha)
    label38.place(x=838, y=390)
    
    global label39
    img39 = Image.open('./Server/Images/ww.png')
    resize39 = img39.resize((80, 80))
    img_39 = ImageTk.PhotoImage(resize39)
    label39 = Label(win1, image=img_39,bg="#00FA9A",bd=0)
    label39.place(x = 600,y=130)
    
    global label40
    img40 = Image.open('./Server/Images/submit.png')
    resize40 = img40.resize((150, 50))
    img_40 = ImageTk.PhotoImage(resize40)
    label40 = Button(win1, image=img_40, relief=FLAT, bg='#00FA9A', bd=0, activebackground='#00FA9A',command=verify_login_credentials)
    label40.place(x=340, y=440)
    
    global label41
    login_str = 'Forgot Password ?'
    label41 = Label(win1, text=login_str, relief=FLAT, bg='#00FA9A', fg='white', bd=0)
    label41.config(font=('arial', 16, 'underline'))
    label41.place(x=320, y=570)
    global label42
    img42 = Image.open('./Server/Images/clickhere.png')
    resize42 = img42.resize((90, 50))
    img_42 = ImageTk.PhotoImage(resize42)
    label42 = Button(win1, image=img_42, relief=FLAT, bg='#00FA9A', bd=0, activebackground='#00FA9A',command=forgot_password)
    label42.place(x=500, y=560)
    
    global label43
    img43 = Image.open('./Server/Images/signup.png')
    resize43 = img43.resize((134, 50))
    img_43 = ImageTk.PhotoImage(resize43)
    label43 = Button(win1, image=img_43,bg="#00FA9A",bd=0, activebackground='#00FA9A',command=login_signup_clicked)
    label43.place(x = 830,y=560)
    
    

    win1.mainloop()
    
def signup():
    gen_captcha()

    # global label1
    # img1 = Image.open('./Server/Images/logo.jpg')
    # resize1 = img1.resize((50, 50))
    # img_1 = ImageTk.PhotoImage(resize1)
    # label1 = Label(win1, image=img_1,bg="orange")
    # label1.place(x = 614,y=5)

    global label2
    label2 = Label(win1, bg="#00FA9A", relief=RIDGE, borderwidth=10, width=95, height=38)
    label2.place(x=292, y=30)

    global label3
    img3 = Image.open('./Server/Images/signup.png')
    resize3 = img3.resize((176, 54))
    img_3 = ImageTk.PhotoImage(resize3)
    label3 = Label(win1, image=img_3, bg='#00FA9A')
    label3.place(x=550, y=43)

    global label4
    label4 = Label(win1, text='USERNAME:', bg='#00FA9A')
    label4.config(font=('georgia', 15, 'bold'))
    label4.place(x=340, y=100)
    global text1
    text1 = tk.Entry(master=win1, width=25,relief=RIDGE,borderwidth=3)
    text1.config(font=('times new roman', 17))
    text1.place(x=340, y=130)
    text1.focus_set()

    global label5
    label5 = Label(win1, text='NAME:', bg='#00FA9A')
    label5.config(font=('georgia', 15, 'bold'))
    label5.place(x=340, y=165)
    global text2
    text2 = tk.Entry(master=win1, width=25,relief=RIDGE,borderwidth=3)
    text2.config(font=('times new roman', 17))
    text2.place(x=340, y=195)
    global text3
    text3 = tk.Entry(master=win1, width=25,relief=RIDGE,borderwidth=3)
    text3.config(font=('times new roman', 17))
    text3.place(x=650, y=195)

    global label6
    label6 = Label(win1, text='EMAIL:', bg='#00FA9A')
    label6.config(font=('georgia', 15, 'bold'))
    label6.place(x=340, y=230)
    global text4
    text4 = tk.Entry(master=win1, width=35,relief=RIDGE,borderwidth=3)
    text4.config(font=('times new roman', 17))
    text4.place(x=340, y=260)

    global label7
    label7 = Label(win1, text='MOBILE NO:', bg='#00FA9A')
    label7.config(font=('georgia', 15, 'bold'))
    label7.place(x=760, y=230)
    global text5
    text5 = tk.Entry(master=win1, width=15,relief=RIDGE,borderwidth=3)
    text5.config(font=('times new roman', 17))
    text5.place(x=760, y=260)

    global label8
    label8 = Label(win1, text='PASSWORD:', bg='#00FA9A')
    label8.config(font=('georgia', 15, 'bold'))
    label8.place(x=340, y=295)
    global text6
    text6 = tk.Entry(master=win1, width=25, show='*',relief=RIDGE,borderwidth=3)
    text6.config(font=('times new roman', 17))
    text6.place(x=340, y=325)
    global text7
    text7 = tk.Entry(master=win1, width=25,relief=RIDGE,borderwidth=3)
    text7.config(font=('times new roman', 17))
    text7.place(x=650, y=325)

    global label11
    label11 = Label(win1, text='CAPTCHA:', bg='#00FA9A')
    label11.config(font=('georgia', 15, 'bold'))
    label11.place(x=340, y=360)
    global text8
    text8 = tk.Entry(master=win1, width=25,relief=RIDGE,borderwidth=3)
    text8.config(font=('times new roman', 17))
    text8.place(x=340, y=390)
    global label14
    label14 = Label(win1, text=captcha, relief=RIDGE, bg='black', fg='white', borderwidth=2, width=13, height=1)
    label14.config(font=('georgia', 15, 'bold'))
    label14.place(x=650, y=390)

    global label13
    img13 = Image.open('./Server/Images/captcha.png')
    resize13 = img13.resize((24, 24))
    img_13 = ImageTk.PhotoImage(resize13)
    label13 = Button(win1, image=img_13, bg="white", command=gen_captcha)
    label13.place(x=838, y=390)

    global label9
    label9 = Label(win1, text='GENDER:', bg='#00FA9A')
    label9.config(font=('georgia', 15, 'bold'))
    label9.place(x=340, y=425)
    global CheckVar1, CheckVar2, CheckVar3
    CheckVar1 = IntVar()
    CheckVar2 = IntVar()
    CheckVar3 = IntVar()
    global check1, check2, check3
    check1 = Checkbutton(win1, text="MALE", bg='#00FA9A', activebackground='#00FA9A', relief=RIDGE,
                         selectcolor='yellow',
                         variable=CheckVar1, onvalue=1, offvalue=0, height=1, width=10,
                         command=disable_female_other_check)
    check1.config(font=('times new roman', 12, 'bold'))
    check1.place(x=340, y=460)
    check2 = Checkbutton(win1, text="FEMALE", bg='#00FA9A', activebackground='#00FA9A', relief=RIDGE,
                         selectcolor='yellow',
                         variable=CheckVar2, onvalue=1, offvalue=0, height=1, width=10,
                         command=disable_other_male_check)
    check2.config(font=('times new roman', 12, 'bold'))
    check2.place(x=450, y=460)
    check3 = Checkbutton(win1, text="OTHER", bg='#00FA9A', activebackground='#00FA9A', relief=RIDGE,
                         selectcolor='yellow',
                         variable=CheckVar3, onvalue=1, offvalue=0, height=1, width=10,
                         command=disable_male_female_check)
    check3.config(font=('times new roman', 12, 'bold'))
    check3.place(x=560, y=460)

    global label10
    label10 = Label(win1, text='Two-Factor Security:', bg='#00FA9A')
    label10.config(font=('georgia', 15, 'bold'))
    label10.place(x=340, y=500)
    global CheckVar4, CheckVar5
    CheckVar4 = IntVar()
    CheckVar4.set(1)
    CheckVar5 = IntVar()

    global check4, check5
    check4 = Checkbutton(win1, text="YES", bg='#00FA9A', activebackground='#00FA9A', selectcolor='pink',
                         variable=CheckVar4, onvalue=1, offvalue=0, height=1, width=10, command=enable_security_check)
    check4.config(font=('times new roman', 12, 'bold'))
    check4.place(x=570, y=500)
    check5 = Checkbutton(win1, text="NO", bg='#00FA9A', activebackground='#00FA9A', selectcolor='pink',
                         variable=CheckVar5, onvalue=1, offvalue=0, height=1, width=10, command=disable_security_check)
    check5.config(font=('times new roman', 12, 'bold'))
    check5.place(x=680, y=500)
    global label15
    img15 = Image.open('./Server/Images/submit.png')
    resize15 = img15.resize((150, 50))
    img_15 = ImageTk.PhotoImage(resize15)
    label15 = Button(win1, image=img_15, relief=FLAT, bg='#00FA9A', bd=0, activebackground='#00FA9A',command=verify_data)
    label15.place(x=340, y=540)

    global label16
    login_str = 'Already have an Account?'
    label16 = Label(win1, text=login_str, relief=FLAT, bg='#00FA9A', fg='white', bd=0)
    label16.config(font=('arial', 16, 'underline'))
    label16.place(x=590, y=577)
    global label17
    img17 = Image.open('./Server/Images/login.png')
    resize17 = img17.resize((120, 41))
    img_17 = ImageTk.PhotoImage(resize17)
    label17 = Button(win1, image=img_17, relief=FLAT, bg='#00FA9A', bd=0, activebackground='#00FA9A',command=signup_login_clicked)
    label17.place(x=840, y=565)

    win1.mainloop()


win1()
