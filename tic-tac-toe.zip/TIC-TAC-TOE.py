import tkinter as tk
from tkinter import *
from PIL import Image,ImageTk
import webbrowser
from tkinter import messagebox
import random

def exit1():
    exit()

def win1():
    global window1
    window1 = tk.Tk()
    # Title of the window
    window1.title('TIC-TAC-TOE')
    # Dimension of Window
    window1.geometry('1100x650')
    # Stop resizing the window
    window1.resizable(False, False)

    global label1
    global btn2
    img1 = Image.open('./images/display1.png')
    resize1 = img1.resize((1100, 650))
    img_1 = ImageTk.PhotoImage(resize1)
    label1 = Label(window1, image=img_1,bg="black")
    label1.pack()

    img2 = Image.open('./images/start.png')
    resize2 = img2.resize((260, 80))
    img_2 = ImageTk.PhotoImage(resize2)
    btn2 = Button(window1, image=img_2,relief=RAISED,borderwidth=5,command=destroywin1,bg="black")
    btn2.place(x=760,y=380)

    window1.mainloop()

global friend
global computer
friend = False
computer = False
global playactive
playactive=False
global textlabeldestroyed
textlabeldestroyed=False

def friendcall():
    global btn3
    global btn4
    global label9
    global label10
    global friend
    global playactive
    friend = True
    btn4.destroy()
    # friend Green Check
    img10 = Image.open('./images/check.jpg')
    resize10 = img10.resize((50, 50))
    img_10 = ImageTk.PhotoImage(resize10)
    label9 = Label(window1, image=img_10, bg="black", relief=RIDGE, borderwidth=5)
    label9.place(x=410, y=305)

    playactive = True
    play()
    window1.mainloop()

def computercall():
    global btn3
    global btn4
    global label9
    global label10
    global computer
    global playactive
    computer = True
    btn3.destroy()
    # computer Green Check
    img11 = Image.open('./images/check.jpg')
    resize11 = img11.resize((50, 50))
    img_11 = ImageTk.PhotoImage(resize11)
    label10 = Label(window1, image=img_11, bg="black", relief=RIDGE, borderwidth=5)
    label10.place(x=410, y=385)
    playactive = True

    play()
    window1.mainloop()
def play():
    if friend==True or computer==True:
        global label11
        img12 = Image.open('./images/play1.jpg')
        resize12 = img12.resize((345,70))
        img_12 = ImageTk.PhotoImage(resize12)
        label11 = Button(window1, image=img_12,relief=RAISED,borderwidth=5, bg="black",command=destroywin2)
        label11.place(x=140, y=470)
        window1.mainloop()

def reset1():
    global friend
    global computer
    friend=False
    computer=False
    label4.destroy()
    label5.destroy()
    label6.destroy()
    text1.destroy()
    label7.destroy()
    label8.destroy()
    if friend==True:
        label9.destroy()
    elif computer==True:
        label10.destroy()
    btn3.destroy()
    btn4.destroy()
    if playactive==True:
        label11.destroy()
    label12.destroy()
    label13.destroy()
    win2()

def win2():
    global label4
    img5 = Image.open('./images/display2.jpg')
    resize5 = img5.resize((1100, 650))
    img_5 = ImageTk.PhotoImage(resize5)
    label4 = Label(window1, image=img_5,bg="black")
    label4.pack()

    global label5
    img6 = Image.open('./images/nametext.jpg')
    resize6 = img6.resize((300, 80))
    img_6 = ImageTk.PhotoImage(resize6)
    label5 = Label(window1, image=img_6,bg="black")
    label5.place(x=130,y=70)

    global label6
    img7 = Image.open('./images/textbox.jpg')
    resize7 = img7.resize((300, 65))
    img_7 = ImageTk.PhotoImage(resize7)
    label6 = Label(window1, image=img_7,bg="black")
    label6.place(x=130,y=165)
    global text1
    text1 = tk.Entry(master=window1, width=17)
    text1.config(font=('Arial bold', 22))
    text1.place(x=143, y=180)
    # To make Text Box Active
    text1.focus_set()

    global textlabel
    dfltstr="Type your name..."
    textlabel=Button(window1,text=dfltstr,width=23,relief=FLAT,borderwidth=0,fg="#C0C0C0",bg="#F5F5F5",command=destroytextlabel)
    textlabel.config(font=('Georgia', 15, "italic"))
    textlabel.place(x=141, y=180)

    def getname():
        if  textlabeldestroyed==False:
            global textlabel
            textlabel.destroy()
        global username
        username=text1.get()
        text1.destroy()
        label7.destroy()
        global label8
        img9 = Image.open('./images/submitted.jpg')
        resize9 = img9.resize((240, 40))
        img_9 = ImageTk.PhotoImage(resize9)
        label8 = Label(window1, image=img_9, bg="black")
        label8.place(x=159, y=178)

        global btn3
        global btn4
        # friend Button
        btn3 = Button(window1, width=12,bg="lime green",text="FRIEND",relief=RAISED,borderwidth=10,command=friendcall)
        btn3.config(font=('Georgia', 20,"italic"))
        btn3.place(x=170, y=300)
        # computer Button
        btn4 = Button(window1, width=12,bg="red",text="COMPUTER",relief=RAISED,borderwidth=10,command=computercall)
        btn4.config(font=('Georgia', 20,"italic"))
        btn4.place(x=170, y=380)

        global label12
        img13 = Image.open('./images/quit.jpg')
        resize13 = img13.resize((80, 50))
        img_13 = ImageTk.PhotoImage(resize13)
        label12= Button(window1, image=img_13,relief=RAISED,borderwidth=5, bg="black",command=exit1)
        label12.place(x=212, y=565)

        global label13
        img14 = Image.open('./images/reset.jpg')
        resize14 = img14.resize((80, 50))
        img_14 = ImageTk.PhotoImage(resize14)
        label13 = Button(window1, image=img_14,relief=RAISED,borderwidth=5, bg="black",command=reset1)
        label13.place(x=325, y=565)

        window1.mainloop()

    global label7
    img8 = Image.open('./images/enter.jpg')
    resize8 = img8.resize((80, 30))
    img_8 = ImageTk.PhotoImage(resize8)
    label7 = Button(window1, image=img_8,bg="black",command=getname)
    label7.place(x=235,y=243)

    window1.mainloop()

def destroytextlabel():
    global textlabel
    textlabel.destroy()
    global textlabeldestroyed
    textlabeldestroyed=True

def reset2():
    global label12
    label12.destroy()
    global label13
    label13.destroy()
    global label14
    label14.destroy()
    global label15
    label14.destroy()
    if blocks==True:
        global block1
        block1.destroy()
        global block2
        block2.destroy()
        global block3
        block3.destroy()
        global block4
        block4.destroy()
        global block5
        block5.destroy()
        global block6
        block6.destroy()
        global block7
        block7.destroy()
        global block8
        block8.destroy()
        global block9
        block9.destroy()

    global game11
    global game12
    global game13
    global game15
    global res_clicked

    if game11 == True:
        global gamename12
        gamename12.destroy()
        game11 = False
    if game12 == True:
        global gamename13
        gamename13.destroy()
    if game13 == True:
        global gamename14
        gamename14.destroy()
    if game15 == True:
        global gamename15
        gamename15.destroy()
    if res_clicked == True:
        global label34
        label34.destroy()

    win3_friend()

def reset_c():
    global label12
    label12.destroy()
    global label13
    label13.destroy()
    global label14
    label14.destroy()
    global label15
    label14.destroy()
    if blocks==True:
        global block1
        block1.destroy()
        global block2
        block2.destroy()
        global block3
        block3.destroy()
        global block4
        block4.destroy()
        global block5
        block5.destroy()
        global block6
        block6.destroy()
        global block7
        block7.destroy()
        global block8
        block8.destroy()
        global block9
        block9.destroy()

    global game11
    global game12
    global game13
    global game15
    global res_clicked

    if game11 == True:
        global gamename12
        gamename12.destroy()
        game11 = False
    if game12 == True:
        global gamename13
        gamename13.destroy()
    if game13 == True:
        global gamename14
        gamename14.destroy()
    if game15 == True:
        global gamename15
        gamename15.destroy()
    if res_clicked == True:
        global label34
        label34.destroy()

    win3_computer()

def about():
    #path2 = '"C://Program Files/Mozilla Firefox/firefox.exe" %s'
    #webbrowser.get(path2).open('vashishthahari.weebly.com/')
    webbrowser.open('vashishthahari.weebly.com/')
def feedback():
    #path2 = '"C://Program Files/Mozilla Firefox/firefox.exe" %s'
    #webbrowser.get(path2).open('vashishthahari.weebly.com/feedback')
    webbrowser.open('vashishthahari.weebly.com/feedback')
def rulesmessage():
    rules="1.Win: If the player has two in a row, they can place a third to get three in a row.\n\n" \
          "2.Block: If the opponent has two in a row, the player must play the third themselves to block the opponent.\n\n" \
          "3.Fork: Cause a scenario where the player has two ways to win (two non-blocked lines of 2).\n\n" \
          "4.Blocking an opponent's fork: If there is only one possible fork for the opponent, the player should block it." \
          "Otherwise, the player should block all forks in any way that simultaneously allows them to make two in a row." \
          "Otherwise, the player should make a two in a row to force the opponent into defending, as long as it does not result in them producing a fork." \
          "For example, if X has two opposite corners and O has the center, O must not play a corner move to win." \
          "(Playing a corner move in this scenario produces a fork for X to win.)\n\n" \
          "5.Center: A player marks the center. (If it is the first move of the game, playing a corner move gives the second player more" \
          "opportunities to make a mistake and may therefore be the better choice; however, it makes no difference between perfect players.)\n\n" \
          "6.Opposite corner: If the opponent is in the corner, the player plays the opposite corner.\n\n" \
          "7.Empty corner: The player plays in a corner square.\n\n" \
          "8.Empty side: The player plays in a middle square on any of the four sides."
    messagebox.showinfo("Rules", rules)
def tricksmessage():
    tricks="=> Acc. to board symmetries (i.e. rotations and reflections), there are only 138 terminal board positions.\n" \
           "A combinatorics study of the game shows that when X makes the first move every time, the game outcomes are as follows:\n\n" \
           "1. 91 distinct positions are won by (X)\n\n" \
           "2. 44 distinct positions are won by (O)\n\n" \
           "3. 3 distinct positions are drawn (often called a 'cat's game')"
    messagebox.showinfo("Tricks", tricks)
def previouswarning():
    warning="You started the game,You can't go back.\nClick on 'RESET' after that you can go back to Previous"
    messagebox.showwarning("Warning", warning)

def globals():
    global b1
    global b2
    global b3
    global b4
    global b5
    global b6
    global b7
    global b8
    global b9
    b1, b2, b3, b4, b5, b6, b7, b8, b9 = 0, 0, 0, 0, 0, 0, 0, 0, 0

    global r1
    global r2
    global r3
    global r4
    global r5
    global r6
    global r7
    global r8
    global r9
    r1, r2, r3, r4, r5, r6, r7, r8, r9 = 0, 0, 0, 0, 0, 0, 0, 0, 0

    global g1
    global g2
    global g3
    global g4
    global g5
    global g6
    global g7
    global g8
    global g9
    g1, g2, g3, g4, g5, g6, g7, g8, g9 = 0, 0, 0, 0, 0, 0, 0, 0, 0

    global result
    result = False

    global tempclick
    tempclick = 0

    global blocks
    blocks=False

    global redwinner
    redwinner=False

    global greenwinner
    greenwinner=False

    global tiedwinner
    tiedwinner=False

    global res_clicked
    res_clicked=False

    global game15
    game15=False

    global previousactive
    previousactive = True

    global list1
    list1=[1,2,3,4,5,6,7,8,9]

globals()

def choiceglobals():
    global choice1
    global choice2
    global choice3
    global choice4
    global choice5
    global choice6
    global choice7
    global choice8
    global choice9
choiceglobals()
choice1, choice2, choice3, choice4, choice5 = 0, 0, 0, 0, 0
choice6, choice7, choice8, choice9 = 0, 0, 0, 0

def computer1():
    choiceglobals()
    if choice==1:
        block_1_c()
    if choice==2:
        block_2_c()
    if choice==3:
        block_3_c()
    if choice==4:
        block_4_c()
    if choice==5:
        block_5_c()
    if choice==6:
        block_6_c()
    if choice==7:
        block_7_c()
    if choice==8:
        block_8_c()
    if choice==9:
        block_9_c()

def yourturn():
    global gamename13
    global game12
    game12=True
    str1="Your Turn..."
    gamename13=Label(window1,text=str1,width=15,relief=RIDGE,borderwidth=5,fg="yellow",bg="#228B22")
    gamename13.config(font=('Georgia', 25, "bold"))
    gamename13.place(x=577, y=170)

def opponentturn():
    global gamename14
    global game13
    game13=True
    str2="Opponent Turn..."
    gamename14=Label(window1,text=str2,width=15,relief=RIDGE,borderwidth=5,fg="yellow",bg="#228B22")
    gamename14.config(font=('Georgia', 25, "bold"))
    gamename14.place(x=577, y=170)

#  FRIEND Blocks LOGIC

def block_1():
    global result

    if result == False:
        global tempclick
        b1 = tempclick + 1
        tempclick = b1
        block1.destroy()
        if (tempclick == 1 or tempclick == 3 or tempclick == 5 or tempclick == 7 or tempclick == 9):
            global r1
            r1 = 1
            opponentturn()
            checkresult()
            global label16
            img19 = Image.open('./images/redheart.png')
            resize19 = img19.resize((75, 75))
            img_19 = ImageTk.PhotoImage(resize19)
            label16 = Label(window1, image=img_19, bg="#56bdbc")
            label16.place(x=597, y=272)

            window1.mainloop()
        elif (tempclick == 2 or tempclick == 4 or tempclick == 6 or tempclick == 8):
            global g1
            g1 = 1
            yourturn()
            checkresult()
            global label25
            img28 = Image.open('./images/greencircle.png')
            resize28 = img28.resize((75, 75))
            img_28 = ImageTk.PhotoImage(resize28)
            label25 = Label(window1, image=img_28, bg="#56bdbc")
            label25.place(x=597, y=272)
            window1.mainloop()


def block_2():
    global result

    if result == False:
        global tempclick
        b2 = tempclick + 1
        tempclick = b2
        block2.destroy()
        if (tempclick == 1 or tempclick == 3 or tempclick == 5 or tempclick == 7 or tempclick == 9):
            global r2
            r2 = 1
            opponentturn()
            checkresult()
            global label17
            img20 = Image.open('./images/redheart.png')
            resize20 = img20.resize((75, 75))
            img_20 = ImageTk.PhotoImage(resize20)
            label17 = Label(window1, image=img_20, bg="#56bdbc")
            label17.place(x=707, y=272)
            window1.mainloop()
        elif (tempclick == 2 or tempclick == 4 or tempclick == 6 or tempclick == 8):
            global g2
            g2 = 1
            yourturn()
            checkresult()
            global label26
            img29 = Image.open('./images/greencircle.png')
            resize29 = img29.resize((75, 75))
            img_29 = ImageTk.PhotoImage(resize29)
            label26 = Label(window1, image=img_29, bg="#56bdbc")
            label26.place(x=707, y=272)
            window1.mainloop()


def block_3():
    global result

    if result == False:
        global tempclick
        b3 = tempclick + 1
        tempclick = b3
        block3.destroy()
        if (tempclick == 1 or tempclick == 3 or tempclick == 5 or tempclick == 7 or tempclick == 9):
            global r3
            r3 = 1
            opponentturn()
            checkresult()
            global label18
            img21 = Image.open('./images/redheart.png')
            resize21 = img21.resize((75, 75))
            img_21 = ImageTk.PhotoImage(resize21)
            label18 = Label(window1, image=img_21, bg="#56bdbc")
            label18.place(x=817, y=272)
            window1.mainloop()
        elif (tempclick == 2 or tempclick == 4 or tempclick == 6 or tempclick == 8):
            global g3
            g3 = 1
            yourturn()
            checkresult()
            global label27
            img30 = Image.open('./images/greencircle.png')
            resize30 = img30.resize((75, 75))
            img_30 = ImageTk.PhotoImage(resize30)
            label27 = Label(window1, image=img_30, bg="#56bdbc")
            label27.place(x=817, y=272)
            window1.mainloop()

def block_4():
    global result

    if result == False:
        global tempclick
        b4 = tempclick + 1
        tempclick = b4
        block4.destroy()
        if (tempclick == 1 or tempclick == 3 or tempclick == 5 or tempclick == 7 or tempclick == 9):
            global r4
            r4 = 1
            opponentturn()
            checkresult()
            global label19
            img22 = Image.open('./images/redheart.png')
            resize22 = img22.resize((75, 75))
            img_22 = ImageTk.PhotoImage(resize22)
            label19 = Label(window1, image=img_22, bg="#56bdbc")
            label19.place(x=597, y=378)
            window1.mainloop()
        elif (tempclick == 2 or tempclick == 4 or tempclick == 6 or tempclick == 8):
            global g4
            g4 = 1
            yourturn()
            checkresult()
            global label28
            img31 = Image.open('./images/greencircle.png')
            resize31 = img31.resize((75, 75))
            img_31 = ImageTk.PhotoImage(resize31)
            label28 = Label(window1, image=img_31, bg="#56bdbc")
            label28.place(x=597, y=378)
            window1.mainloop()

def block_5():
    global result

    if result == False:
        global tempclick
        b5 = tempclick + 1
        tempclick = b5
        block5.destroy()
        if (tempclick == 1 or tempclick == 3 or tempclick == 5 or tempclick == 7 or tempclick == 9):
            global r5
            r5 = 1
            opponentturn()
            checkresult()
            global label20
            img23 = Image.open('./images/redheart.png')
            resize23 = img23.resize((75, 75))
            img_23 = ImageTk.PhotoImage(resize23)
            label20 = Label(window1, image=img_23, bg="#56bdbc")
            label20.place(x=707, y=378)
            window1.mainloop()
        elif (tempclick == 2 or tempclick == 4 or tempclick == 6 or tempclick == 8):
            global g5
            g5 = 1
            yourturn()
            checkresult()
            global label29
            img32 = Image.open('./images/greencircle.png')
            resize32 = img32.resize((75, 75))
            img_32 = ImageTk.PhotoImage(resize32)
            label29 = Label(window1, image=img_32, bg="#56bdbc")
            label29.place(x=707, y=378)
            window1.mainloop()

def block_6():
    global result

    if result == False:
        global tempclick
        b6 = tempclick + 1
        tempclick = b6
        block6.destroy()
        if (tempclick == 1 or tempclick == 3 or tempclick == 5 or tempclick == 7 or tempclick == 9):
            global r6
            r6 = 1
            opponentturn()
            checkresult()
            global label21
            img24 = Image.open('./images/redheart.png')
            resize24 = img24.resize((75, 75))
            img_24 = ImageTk.PhotoImage(resize24)
            label21 = Label(window1, image=img_24, bg="#56bdbc")
            label21.place(x=817, y=378)
            window1.mainloop()
        elif (tempclick == 2 or tempclick == 4 or tempclick == 6 or tempclick == 8):
            global g6
            g6 = 1
            yourturn()
            checkresult()
            global label30
            img33 = Image.open('./images/greencircle.png')
            resize33 = img33.resize((75, 75))
            img_33 = ImageTk.PhotoImage(resize33)
            label30 = Label(window1, image=img_33, bg="#56bdbc")
            label30.place(x=817, y=378)
            window1.mainloop()

def block_7():
    global result

    if result == False:
        global tempclick
        b7 = tempclick + 1
        tempclick = b7
        block7.destroy()
        if (tempclick == 1 or tempclick == 3 or tempclick == 5 or tempclick == 7 or tempclick == 9):
            global r7
            r7 = 1
            opponentturn()
            checkresult()
            global label22
            img25 = Image.open('./images/redheart.png')
            resize25 = img25.resize((75, 74))
            img_25 = ImageTk.PhotoImage(resize25)
            label22 = Label(window1, image=img_25, bg="#56bdbc")
            label22.place(x=597, y=481)
            window1.mainloop()
        elif (tempclick == 2 or tempclick == 4 or tempclick == 6 or tempclick == 8):
            global g7
            g7 = 1
            yourturn()
            checkresult()
            global label31
            img34 = Image.open('./images/greencircle.png')
            resize34 = img34.resize((75, 74))
            img_34 = ImageTk.PhotoImage(resize34)
            label31 = Label(window1, image=img_34, bg="#56bdbc")
            label31.place(x=597, y=481)
            window1.mainloop()

def block_8():
    global result

    if result == False:
        global tempclick
        b8 = tempclick + 1
        tempclick = b8
        block8.destroy()
        if (tempclick == 1 or tempclick == 3 or tempclick == 5 or tempclick == 7 or tempclick == 9):
            global r8
            r8 = 1
            opponentturn()
            checkresult()
            global label23
            img26 = Image.open('./images/redheart.png')
            resize26 = img26.resize((75, 74))
            img_26 = ImageTk.PhotoImage(resize26)
            label23 = Label(window1, image=img_26, bg="#56bdbc")
            label23.place(x=707, y=481)
            window1.mainloop()
        elif (tempclick == 2 or tempclick == 4 or tempclick == 6 or tempclick == 8):
            global g8
            g8 = 1
            yourturn()
            checkresult()
            global label32
            img35 = Image.open('./images/greencircle.png')
            resize35 = img35.resize((75, 74))
            img_35 = ImageTk.PhotoImage(resize35)
            label32 = Label(window1, image=img_35, bg="#56bdbc")
            label32.place(x=707, y=481)
            window1.mainloop()

def block_9():
    global result

    if result == False:
        global tempclick
        b9 = tempclick + 1
        tempclick = b9
        block9.destroy()
        if (tempclick == 1 or tempclick == 3 or tempclick == 5 or tempclick == 7 or tempclick == 9):
            global r9
            r9 = 1
            opponentturn()
            checkresult()
            global label24
            img27 = Image.open('./images/redheart.png')
            resize27 = img27.resize((75, 74))
            img_27 = ImageTk.PhotoImage(resize27)
            label24 = Label(window1, image=img_27, bg="#56bdbc")
            label24.place(x=817, y=481)
            window1.mainloop()

        elif (tempclick == 2 or tempclick == 4 or tempclick == 6 or tempclick == 8):
            global g9
            g9 = 1
            yourturn()
            checkresult()
            global label33
            img36 = Image.open('./images/greencircle.png')
            resize36 = img36.resize((75, 74))
            img_36 = ImageTk.PhotoImage(resize36)
            label33 = Label(window1, image=img_36, bg="#56bdbc")
            label33.place(x=817, y=481)
            window1.mainloop()

#  COMPUTER Blocks LOGIC

def block_1_c():
    global result
    if result==False:

        global list1
        if 1 in list1: list1.remove(1)
        global choice
        if len(list1)>=1:
            choice = random.choice(list1)

        global tempclick
        b1 = tempclick + 1
        tempclick = b1

        if (tempclick == 1 or tempclick == 3 or tempclick == 5 or tempclick == 7 or tempclick == 9):
            global r1
            r1 = 1
            opponentturn()
            checkresult()
            global label16
            img19 = Image.open('./images/redheart.png')
            resize19 = img19.resize((75, 75))
            img_19 = ImageTk.PhotoImage(resize19)
            label16 = Label(window1, image=img_19, bg="#56bdbc")
            label16.place(x=597, y=272)
            computer1()
            block1.destroy()
            window1.mainloop()
        elif (tempclick == 2 or tempclick == 4 or tempclick == 6 or tempclick == 8):
            global g1
            g1 = 1
            yourturn()
            checkresult()
            global label25
            img28 = Image.open('./images/greencircle.png')
            resize28 = img28.resize((75, 75))
            img_28 = ImageTk.PhotoImage(resize28)
            label25 = Label(window1, image=img_28, bg="#56bdbc")
            label25.place(x=597, y=272)
            block1.destroy()
            window1.mainloop()

def block_2_c():
    global result
    if result==False:

        global list1
        if 2 in list1: list1.remove(2)
        global choice
        if len(list1)>=1:
            choice = random.choice(list1)

        global tempclick
        b2 = tempclick + 1
        tempclick = b2

        if (tempclick == 1 or tempclick == 3 or tempclick == 5 or tempclick == 7 or tempclick == 9):
            global r2
            r2 = 1
            opponentturn()
            checkresult()
            global label17
            img20 = Image.open('./images/redheart.png')
            resize20 = img20.resize((75, 75))
            img_20 = ImageTk.PhotoImage(resize20)
            label17 = Label(window1, image=img_20, bg="#56bdbc")
            label17.place(x=707, y=272)
            computer1()
            block2.destroy()
            window1.mainloop()
        elif (tempclick == 2 or tempclick == 4 or tempclick == 6 or tempclick == 8):
            global g2
            g2 = 1
            yourturn()
            checkresult()
            global label26
            img29 = Image.open('./images/greencircle.png')
            resize29 = img29.resize((75, 75))
            img_29 = ImageTk.PhotoImage(resize29)
            label26 = Label(window1, image=img_29, bg="#56bdbc")
            label26.place(x=707, y=272)
            block2.destroy()
            window1.mainloop()

def block_3_c():
    global result
    if result==False:

        global list1
        if 3 in list1: list1.remove(3)
        global choice
        if len(list1)>=1:
            choice = random.choice(list1)

        global tempclick
        b3 = tempclick + 1
        tempclick = b3

        if (tempclick == 1 or tempclick == 3 or tempclick == 5 or tempclick == 7 or tempclick == 9):
            global r3
            r3 = 1
            opponentturn()
            checkresult()
            global label18
            img21 = Image.open('./images/redheart.png')
            resize21 = img21.resize((75, 75))
            img_21 = ImageTk.PhotoImage(resize21)
            label18 = Label(window1, image=img_21, bg="#56bdbc")
            label18.place(x=817, y=272)
            computer1()
            block3.destroy()
            window1.mainloop()
        elif (tempclick == 2 or tempclick == 4 or tempclick == 6 or tempclick == 8):
            global g3
            g3 = 1
            yourturn()
            checkresult()
            global label27
            img30 = Image.open('./images/greencircle.png')
            resize30 = img30.resize((75, 75))
            img_30 = ImageTk.PhotoImage(resize30)
            label27 = Label(window1, image=img_30, bg="#56bdbc")
            label27.place(x=817, y=272)
            block3.destroy()
            window1.mainloop()

def block_4_c():
    global result
    if result==False:

        global list1
        if 4 in list1: list1.remove(4)
        global choice
        if len(list1)>=1:
            choice = random.choice(list1)

        global tempclick
        b4 = tempclick + 1
        tempclick = b4

        if (tempclick == 1 or tempclick == 3 or tempclick == 5 or tempclick == 7 or tempclick == 9):
            global r4
            r4 = 1
            opponentturn()
            checkresult()
            global label19
            img22 = Image.open('./images/redheart.png')
            resize22 = img22.resize((75, 75))
            img_22 = ImageTk.PhotoImage(resize22)
            label19 = Label(window1, image=img_22, bg="#56bdbc")
            label19.place(x=597, y=378)
            computer1()
            block4.destroy()
            window1.mainloop()
        elif (tempclick == 2 or tempclick == 4 or tempclick == 6 or tempclick == 8):
            global g4
            g4 = 1
            yourturn()
            checkresult()
            global label28
            img31 = Image.open('./images/greencircle.png')
            resize31 = img31.resize((75, 75))
            img_31 = ImageTk.PhotoImage(resize31)
            label28 = Label(window1, image=img_31, bg="#56bdbc")
            label28.place(x=597, y=378)
            block4.destroy()
            window1.mainloop()

def block_5_c():
    global result
    if result==False:

        global list1
        if 5 in list1: list1.remove(5)
        global choice
        if len(list1)>=1:
            choice = random.choice(list1)
        global tempclick
        b5 = tempclick + 1
        tempclick = b5

        if (tempclick == 1 or tempclick == 3 or tempclick == 5 or tempclick == 7 or tempclick == 9):
            global r5
            r5 = 1
            opponentturn()
            checkresult()
            global label20
            img23 = Image.open('./images/redheart.png')
            resize23 = img23.resize((75, 75))
            img_23 = ImageTk.PhotoImage(resize23)
            label20 = Label(window1, image=img_23, bg="#56bdbc")
            label20.place(x=707, y=378)
            computer1()
            block5.destroy()
            window1.mainloop()
        elif (tempclick == 2 or tempclick == 4 or tempclick == 6 or tempclick == 8):
            global g5
            g5 = 1
            yourturn()
            checkresult()
            global label29
            img32 = Image.open('./images/greencircle.png')
            resize32 = img32.resize((75, 75))
            img_32 = ImageTk.PhotoImage(resize32)
            label29 = Label(window1, image=img_32, bg="#56bdbc")
            label29.place(x=707, y=378)
            block5.destroy()
            window1.mainloop()

def block_6_c():
    global result
    if result==False:

        global list1
        if 6 in list1: list1.remove(6)
        global choice
        if len(list1)>=1:
            choice = random.choice(list1)

        global tempclick
        b6 = tempclick + 1
        tempclick = b6

        if (tempclick == 1 or tempclick == 3 or tempclick == 5 or tempclick == 7 or tempclick == 9):
            global r6
            r6 = 1
            opponentturn()
            checkresult()
            global label21
            img24 = Image.open('./images/redheart.png')
            resize24 = img24.resize((75, 75))
            img_24 = ImageTk.PhotoImage(resize24)
            label21 = Label(window1, image=img_24, bg="#56bdbc")
            label21.place(x=817, y=378)
            computer1()
            block6.destroy()
            window1.mainloop()
        elif (tempclick == 2 or tempclick == 4 or tempclick == 6 or tempclick == 8):
            global g6
            g6 = 1
            yourturn()
            checkresult()
            global label30
            img33 = Image.open('./images/greencircle.png')
            resize33 = img33.resize((75, 75))
            img_33 = ImageTk.PhotoImage(resize33)
            label30 = Label(window1, image=img_33, bg="#56bdbc")
            label30.place(x=817, y=378)
            block6.destroy()
            window1.mainloop()

def block_7_c():
    global result
    if result==False:

        global list1
        if 7 in list1: list1.remove(7)
        global choice
        if len(list1)>=1:
            choice = random.choice(list1)

        global tempclick
        b7 = tempclick + 1
        tempclick = b7

        if (tempclick == 1 or tempclick == 3 or tempclick == 5 or tempclick == 7 or tempclick == 9):
            global r7
            r7 = 1
            opponentturn()
            checkresult()
            global label22
            img25 = Image.open('./images/redheart.png')
            resize25 = img25.resize((75, 74))
            img_25 = ImageTk.PhotoImage(resize25)
            label22 = Label(window1, image=img_25, bg="#56bdbc")
            label22.place(x=597, y=481)
            computer1()
            block7.destroy()
            window1.mainloop()
        elif (tempclick == 2 or tempclick == 4 or tempclick == 6 or tempclick == 8):
            global g7
            g7 = 1
            yourturn()
            checkresult()
            global label31
            img34 = Image.open('./images/greencircle.png')
            resize34 = img34.resize((75, 74))
            img_34 = ImageTk.PhotoImage(resize34)
            label31 = Label(window1, image=img_34, bg="#56bdbc")
            label31.place(x=597, y=481)
            block7.destroy()
            window1.mainloop()

def block_8_c():
    global result
    if result==False:

        global list1
        if 8 in list1: list1.remove(8)
        global choice
        if len(list1)>=1:
            choice = random.choice(list1)

        global tempclick
        b8 = tempclick + 1
        tempclick = b8

        if (tempclick == 1 or tempclick == 3 or tempclick == 5 or tempclick == 7 or tempclick == 9):
            global r8
            r8 = 1
            opponentturn()
            checkresult()
            global label23
            img26 = Image.open('./images/redheart.png')
            resize26 = img26.resize((75, 74))
            img_26 = ImageTk.PhotoImage(resize26)
            label23 = Label(window1, image=img_26, bg="#56bdbc")
            label23.place(x=707, y=481)
            computer1()
            block8.destroy()
            window1.mainloop()
        elif (tempclick == 2 or tempclick == 4 or tempclick == 6 or tempclick == 8):
            global g8
            g8 = 1
            yourturn()
            checkresult()
            global label32
            img35 = Image.open('./images/greencircle.png')
            resize35 = img35.resize((75, 74))
            img_35 = ImageTk.PhotoImage(resize35)
            label32 = Label(window1, image=img_35, bg="#56bdbc")
            label32.place(x=707, y=481)
            block8.destroy()
            window1.mainloop()

def block_9_c():
    global result
    if result==False:

        global list1
        if 9 in list1: list1.remove(9)
        global choice
        if len(list1)>=1:
            choice = random.choice(list1)

        global tempclick
        b9 = tempclick + 1
        tempclick = b9

        if (tempclick == 1 or tempclick == 3 or tempclick == 5 or tempclick == 7 or tempclick == 9):
            global r9
            r9 = 1
            opponentturn()
            checkresult()
            global label24
            img27 = Image.open('./images/redheart.png')
            resize27 = img27.resize((75, 74))
            img_27 = ImageTk.PhotoImage(resize27)
            label24 = Label(window1, image=img_27, bg="#56bdbc")
            label24.place(x=817, y=481)
            computer1()
            block9.destroy()
            window1.mainloop()
        elif (tempclick == 2 or tempclick == 4 or tempclick == 6 or tempclick == 8):
            global g9
            g9 = 1
            yourturn()
            checkresult()
            global label33
            img36 = Image.open('./images/greencircle.png')
            resize36 = img36.resize((75, 74))
            img_36 = ImageTk.PhotoImage(resize36)
            label33 = Label(window1, image=img_36, bg="#56bdbc")
            label33.place(x=817, y=481)
            block9.destroy()
            window1.mainloop()



def resultbtn():
    global gamename15
    global game15
    game15=True
    str2="CHECK RESULT"
    gamename15=Button(window1,text=str2,width=17,relief=GROOVE,borderwidth=7,fg="black",bg="hot pink",command=resultclicked)
    gamename15.config(font=('Georgia', 22, "bold"))
    gamename15.place(x=570, y=159)
def resultclicked():
    global redwinner
    global greenwinner
    global tiedwinner
    global res_clicked
    res_clicked=True
    global label34

    if redwinner==True:

        img37 = Image.open('./images/redwinner.png')
        resize37 = img37.resize((302, 291))
        img_37 = ImageTk.PhotoImage(resize37)
        label34 = Label(window1, image=img_37,relief=FLAT,borderwidth=0)
        label34.place(x=597, y=270)
        window1.mainloop()
    elif greenwinner==True:

        img38 = Image.open('./images/greenwinner.png')
        resize38 = img38.resize((302, 291))
        img_38 = ImageTk.PhotoImage(resize38)
        label34 = Label(window1, image=img_38,relief=FLAT,borderwidth=0)
        label34.place(x=597, y=270)
        window1.mainloop()
    elif tiedwinner==True:
        img39 = Image.open('./images/matchtied.png')
        resize39 = img39.resize((302, 291))
        img_39 = ImageTk.PhotoImage(resize39)
        label34 = Label(window1, image=img_39, relief=FLAT, borderwidth=0)
        label34.place(x=597, y=270)
        window1.mainloop()

def checkresult():
    global result
    global redwinner
    global greenwinner
    global tiedwinner
    if (((r1 == 1) and (r2 == 1) and (r3 == 1)) or ((r4 == 1) and (r5 == 1) and (r6 == 1)) or (
            (r7 == 1) and (r8 == 1) and (r9 == 1))):
        redwinner=True
        resultbtn()
        result = True

    elif (((r1 == 1) and (r4 == 1) and (r7 == 1)) or ((r2 == 1) and (r5 == 1) and (r8 == 1)) or (
            (r3 == 1) and (r6 == 1) and (r9 == 1))):
        redwinner=True
        resultbtn()
        result = True

    elif (((r1 == 1) and (r5 == 1) and (r9 == 1)) or ((r3 == 1) and (r5 == 1) and (r7 == 1))):
        redwinner=True
        resultbtn()
        result = True

    elif (((g1 == 1) and (g2 == 1) and (g3 == 1)) or ((g4 == 1) and (g5 == 1) and (g6 == 1)) or (
            (g7 == 1) and (g8 == 1) and (g9 == 1))):
        greenwinner=True
        resultbtn()
        result = True

    elif (((g1 == 1) and (g4 == 1) and (g7 == 1)) or ((g2 == 1) and (g5 == 1) and (g8 == 1)) or (
            (g3 == 1) and (g6 == 1) and (g9 == 1))):
        greenwinner=True
        resultbtn()
        result = True

    elif (((g1 == 1) and (g5 == 1) and (g9 == 1)) or ((g3 == 1) and (g5 == 1) and (g7 == 1))):
        greenwinner=True
        resultbtn()
        result = True

    elif tempclick==9:
        tiedwinner=True
        resultbtn()
        result = True

def window():
    label13.destroy()
    label14.destroy()

    global button1
    global frame1
    button1.destroy()
    global previousbutton
    previousbutton=False
    button1=Button(frame1,width=8,text="Previous",bg="#EEE8AA",fg="#BDB76B",relief=RAISED,borderwidth=4,command=previouswarning)
    button1.config(font=('Georgia', 12, "italic"))
    button1.grid(row=0,column=0,padx=32)

    global label15
    img18 = Image.open('./images/window.png')
    resize18 = img18.resize((350, 350))
    img_18 = ImageTk.PhotoImage(resize18)
    label15 = Label(window1, image=img_18,bg="black",relief=RAISED,borderwidth=10)
    label15.place(x=563,y=230)

    global game11
    game11=True
    global gamename12
    gamename12 = Label(window1, text="Your Turn...", width=15, relief=RIDGE, borderwidth=5, fg="yellow", bg="#228B22")
    gamename12.config(font=('Georgia', 25, "bold"))
    gamename12.place(x=577, y=170)

    global blocks
    blocks=True
    # Buttons
    global block1
    block1=Button(window1,text=" ",width=3,relief=FLAT,borderwidth=0,bg="#56bdbc",command=block_1)
    block1.config(font=('Georgia', 31, "italic"))
    block1.place(x=597, y=272)

    global block2
    block2=Button(window1,text=" ",width=3,relief=FLAT,borderwidth=0,bg="#56bdbc",command=block_2)
    block2.config(font=('Georgia', 31, "italic"))
    block2.place(x=706, y=272)

    global block3
    block3=Button(window1,text=" ",width=3,relief=FLAT,borderwidth=0,bg="#56bdbc",command=block_3)
    block3.config(font=('Georgia', 31, "italic"))
    block3.place(x=815, y=272)

    global block4
    block4=Button(window1,text=" ",width=3,relief=FLAT,borderwidth=0,bg="#56bdbc",command=block_4)
    block4.config(font=('Georgia', 31, "italic"))
    block4.place(x=597, y=378)

    global block5
    block5=Button(window1,text=" ",width=3,relief=FLAT,borderwidth=0,bg="#56bdbc",command=block_5)
    block5.config(font=('Georgia', 31, "italic"))
    block5.place(x=706, y=378)

    global block6
    block6=Button(window1,text=" ",width=3,relief=FLAT,borderwidth=0,bg="#56bdbc",command=block_6)
    block6.config(font=('Georgia', 31, "italic"))
    block6.place(x=815, y=378)

    global block7
    block7=Button(window1,text=" ",width=3,relief=FLAT,borderwidth=0,bg="#56bdbc",command=block_7)
    block7.config(font=('Georgia', 30, "italic"))
    block7.place(x=597, y=481)

    global block8
    block8=Button(window1,text=" ",width=3,relief=FLAT,borderwidth=0,bg="#56bdbc",command=block_8)
    block8.config(font=('Georgia', 30, "italic"))
    block8.place(x=706, y=481)

    global block9
    block9=Button(window1,text=" ",width=3,relief=FLAT,borderwidth=0,bg="#56bdbc",command=block_9)
    block9.config(font=('Georgia', 30, "italic"))
    block9.place(x=815, y=481)

    window1.mainloop()

def window_c():
    label13.destroy()
    label14.destroy()

    global button1
    global frame1
    button1.destroy()
    global previousbutton
    previousbutton=False
    button1=Button(frame1,width=8,text="Previous",bg="#EEE8AA",fg="#BDB76B",relief=RAISED,borderwidth=4,command=previouswarning)
    button1.config(font=('Georgia', 12, "italic"))
    button1.grid(row=0,column=0,padx=32)

    global label15
    img18 = Image.open('./images/window.png')
    resize18 = img18.resize((350, 350))
    img_18 = ImageTk.PhotoImage(resize18)
    label15 = Label(window1, image=img_18,bg="black",relief=RAISED,borderwidth=10)
    label15.place(x=563,y=230)

    global game11
    game11=True
    global gamename12
    gamename12 = Label(window1, text="Your Turn...", width=15, relief=RIDGE, borderwidth=5, fg="yellow", bg="#228B22")
    gamename12.config(font=('Georgia', 25, "bold"))
    gamename12.place(x=577, y=170)

    global blocks
    blocks=True
    # Buttons
    global block1
    block1=Button(window1,text=" ",width=3,relief=FLAT,borderwidth=0,bg="#56bdbc",command=block_1_c)
    block1.config(font=('Georgia', 31, "italic"))
    block1.place(x=597, y=272)

    global block2
    block2=Button(window1,text=" ",width=3,relief=FLAT,borderwidth=0,bg="#56bdbc",command=block_2_c)
    block2.config(font=('Georgia', 31, "italic"))
    block2.place(x=706, y=272)

    global block3
    block3=Button(window1,text=" ",width=3,relief=FLAT,borderwidth=0,bg="#56bdbc",command=block_3_c)
    block3.config(font=('Georgia', 31, "italic"))
    block3.place(x=815, y=272)

    global block4
    block4=Button(window1,text=" ",width=3,relief=FLAT,borderwidth=0,bg="#56bdbc",command=block_4_c)
    block4.config(font=('Georgia', 31, "italic"))
    block4.place(x=597, y=378)

    global block5
    block5=Button(window1,text=" ",width=3,relief=FLAT,borderwidth=0,bg="#56bdbc",command=block_5_c)
    block5.config(font=('Georgia', 31, "italic"))
    block5.place(x=706, y=378)

    global block6
    block6=Button(window1,text=" ",width=3,relief=FLAT,borderwidth=0,bg="#56bdbc",command=block_6_c)
    block6.config(font=('Georgia', 31, "italic"))
    block6.place(x=815, y=378)

    global block7
    block7=Button(window1,text=" ",width=3,relief=FLAT,borderwidth=0,bg="#56bdbc",command=block_7_c)
    block7.config(font=('Georgia', 30, "italic"))
    block7.place(x=597, y=481)

    global block8
    block8=Button(window1,text=" ",width=3,relief=FLAT,borderwidth=0,bg="#56bdbc",command=block_8_c)
    block8.config(font=('Georgia', 30, "italic"))
    block8.place(x=706, y=481)

    global block9
    block9=Button(window1,text=" ",width=3,relief=FLAT,borderwidth=0,bg="#56bdbc",command=block_9_c)
    block9.config(font=('Georgia', 30, "italic"))
    block9.place(x=815, y=481)

    window1.mainloop()

def win3_friend():

    globals()
    global game11
    global game12
    global game13
    game11=False
    game12=False
    game13=False
    global label12
    img15 = Image.open('./images/display3.jpg')
    resize15 = img15.resize((1100, 650))
    img_15 = ImageTk.PhotoImage(resize15)
    label12 = Label(window1, image=img_15,bg="#8B4513",relief=RAISED,borderwidth=7)
    label12.pack()

    global frame1
    frame1=Frame(window1,width=1090,height=50,bg="#cb455d",relief=SUNKEN,borderwidth=3)
    frame1.place(x=5,y=4)

    global button1
    button1=Button(frame1,width=8,text="Previous",bg="#f0981d",relief=RAISED,borderwidth=4,command=destroywin3)
    button1.config(font=('Georgia', 12, "italic"))
    button1.grid(row=0,column=0,padx=32)
    global button2
    button2=Button(frame1,width=8,text="Feedback",bg="#f0981d",relief=RAISED,borderwidth=4,command=feedback)
    button2.config(font=('Georgia', 12, "italic"))
    button2.grid(row=0,column=1,padx=30)
    global button3
    button3=Button(frame1,width=8,text="Developer",bg="#f0981d",relief=RAISED,borderwidth=4,command=about)
    button3.config(font=('Georgia', 12, "italic"))
    button3.grid(row=0,column=2,padx=30)
    global button4
    button4=Button(frame1,width=8,text="Reset",bg="#f0981d",relief=RAISED,borderwidth=4,command=reset2)
    button4.config(font=('Georgia', 12, "italic"))
    button4.grid(row=0,column=3,padx=30)
    global button5
    button5=Button(frame1,width=8,text="Tricks",bg="#f0981d",relief=RAISED,borderwidth=4,command=tricksmessage)
    button5.config(font=('Georgia', 12, "italic"))
    button5.grid(row=0,column=4,padx=30)
    global button6
    button6=Button(frame1,width=8,text="Rules",bg="#f0981d",relief=RAISED,borderwidth=4,command=rulesmessage)
    button6.config(font=('Georgia', 12, "italic"))
    button6.grid(row=0,column=5,padx=30)
    global button7
    button7=Button(frame1,width=8,text="Exit(X)",bg="#f0981d",relief=RAISED,borderwidth=4,command=exit1)
    button7.config(font=('Georgia', 12, "italic"))
    button7.grid(row=0,column=6,padx=30)

    global gamename17
    gamename17=Label(window1,text="TIC-TAC-TOE",width=14,relief=RIDGE,borderwidth=7,fg="black",bg="aqua")
    gamename17.config(font=('Georgia', 35, "italic"))
    gamename17.place(x=140, y=100)

    global gamename11
    global username
    displayname="Welcome,\n"+str(username)
    gamename11=Label(window1,text=displayname,relief=GROOVE,borderwidth=6,fg="blue",bg="#f0981d")
    gamename11.config(font=('Georgia', 27, "italic"))
    gamename11.place(x=295, y=315)

    global label13
    img16 = Image.open('./images/blurwindow.png')
    resize16 = img16.resize((350, 350))
    img_16 = ImageTk.PhotoImage(resize16)
    label13 = Label(window1, image=img_16,bg="black",relief=RAISED,borderwidth=10)
    label13.place(x=563,y=230)

    global label14
    img17 = Image.open('./images/start1.png')
    resize17 = img17.resize((150,75))
    img_17 = ImageTk.PhotoImage(resize17)
    label14 = Button(window1, image=img_17,bg="black",relief=RAISED,borderwidth=8,command=window)
    label14.place(x=663,y=137)

    window1.mainloop()

def win3_computer():

    globals()
    global game11
    global game12
    global game13
    game11=False
    game12=False
    game13=False
    global label12
    img15 = Image.open('./images/display3.jpg')
    resize15 = img15.resize((1100, 650))
    img_15 = ImageTk.PhotoImage(resize15)
    label12 = Label(window1, image=img_15,bg="#8B4513",relief=RAISED,borderwidth=7)
    label12.pack()

    global frame1
    frame1=Frame(window1,width=1090,height=50,bg="#cb455d",relief=SUNKEN,borderwidth=3)
    frame1.place(x=5,y=4)

    global button1
    button1=Button(frame1,width=8,text="Previous",bg="#f0981d",relief=RAISED,borderwidth=4,command=destroywin3)
    button1.config(font=('Georgia', 12, "italic"))
    button1.grid(row=0,column=0,padx=32)
    global button2
    button2=Button(frame1,width=8,text="Feedback",bg="#f0981d",relief=RAISED,borderwidth=4,command=feedback)
    button2.config(font=('Georgia', 12, "italic"))
    button2.grid(row=0,column=1,padx=30)
    global button3
    button3=Button(frame1,width=8,text="Developer",bg="#f0981d",relief=RAISED,borderwidth=4,command=about)
    button3.config(font=('Georgia', 12, "italic"))
    button3.grid(row=0,column=2,padx=30)
    global button4
    button4=Button(frame1,width=8,text="Reset",bg="#f0981d",relief=RAISED,borderwidth=4,command=reset_c)
    button4.config(font=('Georgia', 12, "italic"))
    button4.grid(row=0,column=3,padx=30)
    global button5
    button5=Button(frame1,width=8,text="Tricks",bg="#f0981d",relief=RAISED,borderwidth=4,command=tricksmessage)
    button5.config(font=('Georgia', 12, "italic"))
    button5.grid(row=0,column=4,padx=30)
    global button6
    button6=Button(frame1,width=8,text="Rules",bg="#f0981d",relief=RAISED,borderwidth=4,command=rulesmessage)
    button6.config(font=('Georgia', 12, "italic"))
    button6.grid(row=0,column=5,padx=30)
    global button7
    button7=Button(frame1,width=8,text="Exit(X)",bg="#f0981d",relief=RAISED,borderwidth=4,command=exit1)
    button7.config(font=('Georgia', 12, "italic"))
    button7.grid(row=0,column=6,padx=30)

    global gamename17
    gamename17=Label(window1,text="TIC-TAC-TOE",width=14,relief=RIDGE,borderwidth=7,fg="black",bg="aqua")
    gamename17.config(font=('Georgia', 35, "italic"))
    gamename17.place(x=140, y=100)

    global gamename11
    global username
    displayname="Welcome,\n"+str(username)
    gamename11=Label(window1,text=displayname,relief=GROOVE,borderwidth=6,fg="blue",bg="#f0981d")
    gamename11.config(font=('Georgia', 27, "italic"))
    gamename11.place(x=295, y=315)

    global label13
    img16 = Image.open('./images/blurwindow.png')
    resize16 = img16.resize((350, 350))
    img_16 = ImageTk.PhotoImage(resize16)
    label13 = Label(window1, image=img_16,bg="black",relief=RAISED,borderwidth=10)
    label13.place(x=563,y=230)

    global label14
    img17 = Image.open('./images/start1.png')
    resize17 = img17.resize((150,75))
    img_17 = ImageTk.PhotoImage(resize17)
    label14 = Button(window1, image=img_17,bg="black",relief=RAISED,borderwidth=8,command=window_c)
    label14.place(x=663,y=137)

    window1.mainloop()

def destroywin1():
    label1.destroy()
    btn2.destroy()
    win2()

def destroywin2():
    label4.destroy()
    label5.destroy()
    label6.destroy()
    text1.destroy()
    label7.destroy()
    label8.destroy()
    if friend==True:
        label9.destroy()
        btn3.destroy()
    elif computer==True:
        label10.destroy()
        btn4.destroy()
    label11.destroy()
    label12.destroy()
    label13.destroy()
    if friend==True:
        win3_friend()
    if computer==True:
        win3_computer()

def destroywin3():
    global friend
    friend=False
    global computer
    computer=False
    global previousactive
    global frame1
    if previousactive==True:
        globals()
        label12.destroy()
        label13.destroy()
        label14.destroy()
        frame1.destroy()
        button1.destroy()
        button2.destroy()
        button3.destroy()
        button4.destroy()
        button5.destroy()
        button6.destroy()
        button7.destroy()
        gamename11.destroy()
        gamename17.destroy()
        win2()



win1()
