import tkinter as tk
from tkinter import *
from PIL import Image,ImageTk
from tkinter import messagebox
from bs4 import BeautifulSoup as bs
import requests
from datetime import date
from datetime import datetime

window = tk.Tk()
# Title of the window
window.title('Real-Time Currency Calculator')
# Dimension of Window
window.geometry('1280x640')
# Stop resizing the window
window.resizable(False,True)


def maindisplay():
    label21.destroy()
    label22.destroy()
    convertlabel.destroy()

    def insert_america():
        valuestored1.set("U.S.A (U.S Dollar)")
    def insert_canada():
        valuestored1.set("Canada (Can. Dollar)")
    def insert_oman():
        valuestored1.set("Oman (Omani Rial)")
    def insert_saudiarabia():
        valuestored1.set("Saudi Arabia (Riyal)")
    def insert_australia():
        valuestored1.set("Australia (Aus. Dollar)")
    def insert_russia():
        valuestored1.set("Russia (Ruble)")
    def insert_newzealand():
        valuestored1.set("NewZealand (NZ Dollar)")
    def insert_southafrica():
        valuestored1.set("South Africa (Rand)")
    def insert_india():
        valuestored1.set("India (Rupees)")
    def insert_pakistan():
        valuestored1.set("Pakistan (Pak. Rupees)")
    def insert_britain():
        valuestored1.set("Britain (Pound)")
    def insert_srilanka():
        valuestored1.set("SriLanka (S.L Rupees)")
    def insert_bangladesh():
        valuestored1.set("Bangladesh (Taka)")
    def insert_germany():
        valuestored1.set("Germany (Euro)")
    def insert_uae():
        valuestored1.set("U.A.E (Dirham)")
    def insert_japan():
        valuestored1.set("Japan (Yen)")
    def exit1():
        exit()

    img1 = Image.open('./images/currency-calculator/display.jpg')
    resize1 = img1.resize((1280, 640))
    img_1 = ImageTk.PhotoImage(resize1)
    label1 = Label(window, image=img_1, bg="black")
    label1.pack()

    label_main = tk.Label(window, text="Currency Convertor", relief=GROOVE, borderwidth=9, width=30, fg="white",
                          bg="#4169E1")
    label_main.config(font=('Algerian', 30))
    label_main.place(x=260, y=7)

    img22 = Image.open('./images/currency-calculator/exit.png')
    resize22 = img22.resize((60,60 ))
    img_22 = ImageTk.PhotoImage(resize22)
    btn22 = Button(window, image=img_22, relief=RIDGE, borderwidth='4', command=exit1)
    btn22.place(x=605, y=130)

    img2 = Image.open('./images/currency-calculator/america.png')
    resize2 = img2.resize((130, 65))
    img_2 = ImageTk.PhotoImage(resize2)
    btn2 = Button(window, image=img_2, command=insert_america)
    btn2.place(x=0, y=7)

    img3 = Image.open('./images/currency-calculator/canada.png')
    resize3 = img3.resize((130, 65))
    img_3 = ImageTk.PhotoImage(resize3)
    btn3 = Button(window, image=img_3, command=insert_canada)
    btn3.place(x=0, y=87)

    img4 = Image.open('./images/currency-calculator/oman.png')
    resize4 = img4.resize((130, 65))
    img_4 = ImageTk.PhotoImage(resize4)
    btn4 = Button(window, image=img_4, command=insert_oman)
    btn4.place(x=0, y=167)

    img5 = Image.open('./images/currency-calculator/saudiarabia.png')
    resize5 = img5.resize((130, 65))
    img_5 = ImageTk.PhotoImage(resize5)
    btn5 = Button(window, image=img_5, command=insert_saudiarabia)
    btn5.place(x=0, y=247)

    img6 = Image.open('./images/currency-calculator/australia.png')
    resize6 = img6.resize((130, 65))
    img_6 = ImageTk.PhotoImage(resize6)
    btn6 = Button(window, image=img_6, command=insert_australia)
    btn6.place(x=0, y=327)

    img7 = Image.open('./images/currency-calculator/russia.png')
    resize7 = img7.resize((130, 65))
    img_7 = ImageTk.PhotoImage(resize7)
    btn7 = Button(window, image=img_7, command=insert_russia)
    btn7.place(x=0, y=407)

    img8 = Image.open('./images/currency-calculator/newzealand.png')
    resize8 = img8.resize((130, 65))
    img_8 = ImageTk.PhotoImage(resize8)
    btn8 = Button(window, image=img_8, command=insert_newzealand)
    btn8.place(x=0, y=487)

    img9 = Image.open('./images/currency-calculator/southafrica.png')
    resize9 = img9.resize((130, 65))
    img_9 = ImageTk.PhotoImage(resize9)
    btn9 = Button(window, image=img_9, command=insert_southafrica)
    btn9.place(x=0, y=567)

    img10 = Image.open('./images/currency-calculator/india.png')
    resize10 = img10.resize((130, 65))
    img_10 = ImageTk.PhotoImage(resize10)
    btn10 = Button(window, image=img_10, command=insert_india)
    btn10.place(x=1145, y=7)

    img12 = Image.open('./images/currency-calculator/pakistan.png')
    resize12 = img12.resize((130, 65))
    img_12 = ImageTk.PhotoImage(resize12)
    btn12 = Button(window, image=img_12, command=insert_pakistan)
    btn12.place(x=1145, y=87)

    img13 = Image.open('./images/currency-calculator/britain.png')
    resize13 = img13.resize((130, 65))
    img_13 = ImageTk.PhotoImage(resize13)
    btn13 = Button(window, image=img_13, command=insert_britain)
    btn13.place(x=1145, y=167)

    img14 = Image.open('./images/currency-calculator/srilanka.png')
    resize14 = img14.resize((130, 65))
    img_14 = ImageTk.PhotoImage(resize14)
    btn14 = Button(window, image=img_14, command=insert_srilanka)
    btn14.place(x=1145, y=247)

    img15 = Image.open('./images/currency-calculator/bangladesh.png')
    resize15 = img15.resize((130, 65))
    img_15 = ImageTk.PhotoImage(resize15)
    btn15 = Button(window, image=img_15, command=insert_bangladesh)
    btn15.place(x=1145, y=327)

    img16 = Image.open('./images/currency-calculator/germany.png')
    resize16 = img16.resize((130, 65))
    img_16 = ImageTk.PhotoImage(resize16)
    btn16 = Button(window, image=img_16, command=insert_germany)
    btn16.place(x=1145, y=407)

    img17 = Image.open('./images/currency-calculator/uae.png')
    resize17 = img17.resize((130, 65))
    img_17 = ImageTk.PhotoImage(resize17)
    btn17 = Button(window, image=img_17, command=insert_uae)
    btn17.place(x=1145, y=487)

    img18 = Image.open('./images/currency-calculator/japan.png')
    resize18 = img18.resize((130, 65))
    img_18 = ImageTk.PhotoImage(resize18)
    btn18 = Button(window, image=img_18, command=insert_japan)
    btn18.place(x=1145, y=567)

    valuestored1 = StringVar(window)
    valuestored1.set('U.S.A (U.S Dollar)')
    listA = {'U.S.A (U.S Dollar)', 'India (Rupees)', 'Britain (Pound)', 'Germany (Euro)', 'Japan (Yen)',
             'NewZealand (NZ Dollar)', 'Bangladesh (Taka)', 'Saudi Arabia (Riyal)', 'Oman (Omani Rial)',
             'Russia (Ruble)', 'South Africa (Rand)', 'Australia (Aus. Dollar)', 'U.A.E (Dirham)',
             'Pakistan (Pak. Rupees)', 'Canada (Can. Dollar)', 'SriLanka (S.L Rupees)'}
    popupMenuA = tk.OptionMenu(window, valuestored1, *listA)
    popupMenuA.config(width=21, font=('Algerian', 20))
    popupMenuA.place(x=200, y=260)
    def change_dropdown_A(*args):
        valuestored1.get()
    valuestored1.trace('w', change_dropdown_A)


    valuestored2 = StringVar(window)
    valuestored2.set('India (Rupees)')
    listB = {'U.S.A (U.S Dollar)', 'India (Rupees)', 'Britain (Pound)', 'Germany (Euro)', 'Japan (Yen)',
             'NewZealand (NZ Dollar)', 'Bangladesh (Taka)', 'Saudi Arabia (Riyal)', 'Oman (Omani Rial)',
             'Russia (Ruble)', 'South Africa (Rand)', 'Australia (Aus. Dollar)', 'U.A.E (Dirham)',
             'Pakistan (Pak. Rupees)', 'Canada (Can. Dollar)', 'SriLanka (S.L Rupees)'}
    popupMenuB = tk.OptionMenu(window, valuestored2, *listB)
    popupMenuB.config(width=21, font=('Algerian', 20))
    popupMenuB.place(x=700, y=260)
    def change_dropdown_B(*args):
        valuestored2.get()
    valuestored2.trace('w', change_dropdown_B)



    global strA, strB
    def swap_1():
        strA = valuestored1.get()
        strB = valuestored2.get()
        valuestored1.set(strB)
        valuestored2.set(strA)

    # SWAP Button
    img19 = Image.open('./images/currency-calculator/swap.png')
    resize19 = img19.resize((50, 33))
    img_19 = ImageTk.PhotoImage(resize19)
    btn19 = Button(window, image=img_19, relief=RIDGE, borderwidth='4', command=swap_1)
    btn19.place(x=612, y=262)
    # First Entry Box
    text1 = tk.Entry(window, width=20, relief=RIDGE, borderwidth=9, bg="#87CEEB")
    text1.config(font=('Arial bold', 25))
    text1.place(x=200, y=337)
    # Second Entry Box
    text2 = tk.Entry(window, width=20, relief=RIDGE, borderwidth=9, bg="#87CEEB")
    text2.config(font=('Arial bold', 25))
    text2.insert(0, "N/A")
    text2.place(x=700, y=337)

    #global valueA, valueB

    def result():
        today = date.today()
        currentdate = today.strftime("%B %d, %Y")
        now = datetime.now()
        currenttime = now.strftime("%H:%M:%S")

        text2.delete(0, tk.END)

        try:
            inputfloat = float(text1.get())
            interror = False
        except:
            text2.insert(0, "Invalid Input!")
            interror = True
            messagebox.showerror("ERROR", "Invalid Input")
        if interror == False:
            storeinputfloat = float(text1.get())
            labelstr = "* Last Updated @ " + str(currenttime) + " on " + currentdate + " . \nSource :- investing.com"
            bottomlabel = tk.Label(window, text=labelstr, width=45, relief=GROOVE, borderwidth=3, fg="#800080",
                                   bg="#A9A9A9")
            bottomlabel.config(font=('Arial bold', 25))
            bottomlabel.place(x=187, y=550)

            if type(storeinputfloat) == float:
                if valuestored1.get() == "U.S.A (U.S Dollar)":
                    usd_usd = 1
                    valueA = usd_usd
                elif valuestored1.get() == "India (Rupees)":
                    page = requests.get("https://in.investing.com/currencies/usd-inr")
                    soup = bs(page.content)
                    content = soup.find_all(class_='last-price-value js-streamable-element')
                    inrstr = [i.text for i in content]
                    inr = (inrstr[0])
                    usd_inr = float(inr)
                    valueA = usd_inr
                elif valuestored1.get() == "Britain (Pound)":
                    page = requests.get("https://in.investing.com/currencies/usd-gbp")
                    soup = bs(page.content)
                    content = soup.find_all(class_='last-price-value js-streamable-element')
                    gbpstr = [i.text for i in content]
                    gbp = (gbpstr[0])
                    usd_gbp = float(gbp)
                    valueA = usd_gbp
                elif valuestored1.get() == "Germany (Euro)":
                    page = requests.get("https://in.investing.com/currencies/usd-eur")
                    soup = bs(page.content)
                    content = soup.find_all(class_='last-price-value js-streamable-element')
                    eurstr = [i.text for i in content]
                    eur = (eurstr[0])
                    usd_eur = float(eur)
                    valueA = usd_eur
                elif valuestored1.get() == "Japan (Yen)":
                    page = requests.get("https://in.investing.com/currencies/usd-jpy")
                    soup = bs(page.content)
                    content = soup.find_all(class_='last-price-value js-streamable-element')
                    jpystr = [i.text for i in content]
                    jpy = (jpystr[0])
                    usd_jpy = float(jpy)
                    valueA = usd_jpy
                elif valuestored1.get() == "NewZealand (NZ Dollar)":
                    page = requests.get("https://in.investing.com/currencies/usd-nzd")
                    soup = bs(page.content)
                    content = soup.find_all(class_='last-price-value js-streamable-element')
                    nzdstr = [i.text for i in content]
                    nzd = (nzdstr[0])
                    usd_nzd = float(nzd)
                    valueA = usd_nzd
                elif valuestored1.get() == "Bangladesh (Taka)":
                    page = requests.get("https://in.investing.com/currencies/usd-bdt")
                    soup = bs(page.content)
                    content = soup.find_all(class_='last-price-value js-streamable-element')
                    bdtstr = [i.text for i in content]
                    bdt = (bdtstr[0])
                    usd_bdt = float(bdt)
                    valueA = usd_bdt
                elif valuestored1.get() == "Saudi Arabia (Riyal)":
                    page = requests.get("https://in.investing.com/currencies/usd-sar")
                    soup = bs(page.content)
                    content = soup.find_all(class_='last-price-value js-streamable-element')
                    sarstr = [i.text for i in content]
                    sar = (sarstr[0])
                    usd_sar = float(sar)
                    valueA = usd_sar
                elif valuestored1.get() == "Oman (Omani Rial)":
                    page = requests.get("https://in.investing.com/currencies/usd-omr")
                    soup = bs(page.content)
                    content = soup.find_all(class_='last-price-value js-streamable-element')
                    omrstr = [i.text for i in content]
                    omr = (omrstr[0])
                    usd_omr = float(omr)
                    valueA = usd_omr
                elif valuestored1.get() == "Russia (Ruble)":
                    page = requests.get("https://in.investing.com/currencies/usd-rub")
                    soup = bs(page.content)
                    content = soup.find_all(class_='last-price-value js-streamable-element')
                    rubstr = [i.text for i in content]
                    rub = (rubstr[0])
                    usd_rub = float(rub)
                    valueA = usd_rub
                elif valuestored1.get() == "South Africa (Rand)":
                    page = requests.get("https://in.investing.com/currencies/usd-zar")
                    soup = bs(page.content)
                    content = soup.find_all(class_='last-price-value js-streamable-element')
                    zarstr = [i.text for i in content]
                    zar = (zarstr[0])
                    usd_zar = float(zar)
                    valueA = usd_zar
                elif valuestored1.get() == "Australia (Aus. Dollar)":
                    page = requests.get("https://in.investing.com/currencies/usd-aud")
                    soup = bs(page.content)
                    content = soup.find_all(class_='last-price-value js-streamable-element')
                    audstr = [i.text for i in content]
                    aud = (audstr[0])
                    usd_aud = float(aud)
                    valueA = usd_aud
                elif valuestored1.get() == "U.A.E (Dirham)":
                    page = requests.get("https://in.investing.com/currencies/usd-aed")
                    soup = bs(page.content)
                    content = soup.find_all(class_='last-price-value js-streamable-element')
                    aedstr = [i.text for i in content]
                    aed = (aedstr[0])
                    usd_aed = float(aed)
                    valueA = usd_aed
                elif valuestored1.get() == "Pakistan (Pak. Rupees)":
                    page = requests.get("https://in.investing.com/currencies/usd-pkr")
                    soup = bs(page.content)
                    content = soup.find_all(class_='last-price-value js-streamable-element')
                    pkrstr = [i.text for i in content]
                    pkr = (pkrstr[0])
                    usd_pkr = float(pkr)
                    valueA = usd_pkr
                elif valuestored1.get() == "Canada (Can. Dollar)":
                    page = requests.get("https://in.investing.com/currencies/usd-cad")
                    soup = bs(page.content)
                    content = soup.find_all(class_='last-price-value js-streamable-element')
                    cadstr = [i.text for i in content]
                    cad = (cadstr[0])
                    usd_cad = float(cad)
                    valueA = usd_cad
                elif valuestored1.get() == "SriLanka (S.L Rupees)":
                    page = requests.get("https://in.investing.com/currencies/usd-lkr")
                    soup = bs(page.content)
                    content = soup.find_all(class_='last-price-value js-streamable-element')
                    lkrstr = [i.text for i in content]
                    lkr = (lkrstr[0])
                    usd_lkr = float(lkr)
                    valueA = usd_lkr

                if valuestored2.get() == "U.S.A (U.S Dollar)":
                    usd_usd = 1
                    valueB = usd_usd
                elif valuestored2.get() == "India (Rupees)":
                    page = requests.get("https://in.investing.com/currencies/usd-inr")
                    soup = bs(page.content)
                    content = soup.find_all(class_='last-price-value js-streamable-element')
                    inrstr = [i.text for i in content]
                    inr = (inrstr[0])
                    usd_inr = float(inr)
                    valueB = usd_inr
                elif valuestored2.get() == "Britain (Pound)":
                    page = requests.get("https://in.investing.com/currencies/usd-gbp")
                    soup = bs(page.content)
                    content = soup.find_all(class_='last-price-value js-streamable-element')
                    gbpstr = [i.text for i in content]
                    gbp = (gbpstr[0])
                    usd_gbp = float(gbp)
                    valueB = usd_gbp
                elif valuestored2.get() == "Germany (Euro)":
                    page = requests.get("https://in.investing.com/currencies/usd-eur")
                    soup = bs(page.content)
                    content = soup.find_all(class_='last-price-value js-streamable-element')
                    eurstr = [i.text for i in content]
                    eur = (eurstr[0])
                    usd_eur = float(eur)
                    valueB = usd_eur
                elif valuestored2.get() == "Japan (Yen)":
                    page = requests.get("https://in.investing.com/currencies/usd-jpy")
                    soup = bs(page.content)
                    content = soup.find_all(class_='last-price-value js-streamable-element')
                    jpystr = [i.text for i in content]
                    jpy = (jpystr[0])
                    usd_jpy = float(jpy)
                    valueB = usd_jpy
                elif valuestored2.get() == "NewZealand (NZ Dollar)":
                    page = requests.get("https://in.investing.com/currencies/usd-nzd")
                    soup = bs(page.content)
                    content = soup.find_all(class_='last-price-value js-streamable-element')
                    nzdstr = [i.text for i in content]
                    nzd = (nzdstr[0])
                    usd_nzd = float(nzd)
                    valueB = usd_nzd
                elif valuestored2.get() == "Bangladesh (Taka)":
                    page = requests.get("https://in.investing.com/currencies/usd-bdt")
                    soup = bs(page.content)
                    content = soup.find_all(class_='last-price-value js-streamable-element')
                    bdtstr = [i.text for i in content]
                    bdt = (bdtstr[0])
                    usd_bdt = float(bdt)
                    valueB = usd_bdt
                elif valuestored2.get() == "Saudi Arabia (Riyal)":
                    page = requests.get("https://in.investing.com/currencies/usd-sar")
                    soup = bs(page.content)
                    content = soup.find_all(class_='last-price-value js-streamable-element')
                    sarstr = [i.text for i in content]
                    sar = (sarstr[0])
                    usd_sar = float(sar)
                    valueB = usd_sar
                elif valuestored2.get() == "Oman (Omani Rial)":
                    page = requests.get("https://in.investing.com/currencies/usd-omr")
                    soup = bs(page.content)
                    content = soup.find_all(class_='last-price-value js-streamable-element')
                    omrstr = [i.text for i in content]
                    omr = (omrstr[0])
                    usd_omr = float(omr)
                    valueB = usd_omr
                elif valuestored2.get() == "Russia (Ruble)":
                    page = requests.get("https://in.investing.com/currencies/usd-rub")
                    soup = bs(page.content)
                    content = soup.find_all(class_='last-price-value js-streamable-element')
                    rubstr = [i.text for i in content]
                    rub = (rubstr[0])
                    usd_rub = float(rub)
                    valueB = usd_rub
                elif valuestored2.get() == "South Africa (Rand)":
                    page = requests.get("https://in.investing.com/currencies/usd-zar")
                    soup = bs(page.content)
                    content = soup.find_all(class_='last-price-value js-streamable-element')
                    zarstr = [i.text for i in content]
                    zar = (zarstr[0])
                    usd_zar = float(zar)
                    valueB = usd_zar
                elif valuestored2.get() == "Australia (Aus. Dollar)":
                    page = requests.get("https://in.investing.com/currencies/usd-aud")
                    soup = bs(page.content)
                    content = soup.find_all(class_='last-price-value js-streamable-element')
                    audstr = [i.text for i in content]
                    aud = (audstr[0])
                    usd_aud = float(aud)
                    valueB = usd_aud
                elif valuestored2.get() == "U.A.E (Dirham)":
                    page = requests.get("https://in.investing.com/currencies/usd-aed")
                    soup = bs(page.content)
                    content = soup.find_all(class_='last-price-value js-streamable-element')
                    aedstr = [i.text for i in content]
                    aed = (aedstr[0])
                    usd_aed = float(aed)
                    valueB = usd_aed
                elif valuestored2.get() == "Pakistan (Pak. Rupees)":
                    page = requests.get("https://in.investing.com/currencies/usd-pkr")
                    soup = bs(page.content)
                    content = soup.find_all(class_='last-price-value js-streamable-element')
                    pkrstr = [i.text for i in content]
                    pkr = (pkrstr[0])
                    usd_pkr = float(pkr)
                    valueB = usd_pkr
                elif valuestored2.get() == "Canada (Can. Dollar)":
                    page = requests.get("https://in.investing.com/currencies/usd-cad")
                    soup = bs(page.content)
                    content = soup.find_all(class_='last-price-value js-streamable-element')
                    cadstr = [i.text for i in content]
                    cad = (cadstr[0])
                    usd_cad = float(cad)
                    valueB = usd_cad
                elif valuestored2.get() == "SriLanka (S.L Rupees)":
                    page = requests.get("https://in.investing.com/currencies/usd-lkr")
                    soup = bs(page.content)
                    content = soup.find_all(class_='last-price-value js-streamable-element')
                    lkrstr = [i.text for i in content]
                    lkr = (lkrstr[0])
                    usd_lkr = float(lkr)
                    valueB = usd_lkr

                finalvalue = str((valueB / valueA) * storeinputfloat)
                text2.insert(0, finalvalue)


        else:
            print("Invalid Input")

    # Calculate Button
    img20 = Image.open('./images/currency-calculator/calculate.jpg')
    resize20 = img20.resize((300, 90))
    img_20 = ImageTk.PhotoImage(resize20)
    btn20 = Button(window, image=img_20, relief=RAISED, borderwidth='5', command=result)
    btn20.place(x=480, y=425)

    window.mainloop()

global label21,convertlabel
img21 = Image.open('./images/currency-calculator/blurdisplay.png')
resize21 = img21.resize((1280, 640))
img_21 = ImageTk.PhotoImage(resize21)
label21 = Label(window, image=img_21, bg="black",relief=FLAT,borderwidth=0)
label21.pack()

label22 = tk.Label(window, text="Real-Time", relief=GROOVE, borderwidth=9, width=30, fg="white",bg="#4169E1")
label22.config(font=('Algerian', 30))
label22.place(x=260, y=7)

convertorstr="Currency\nConvertor"
convertlabel=tk.Button(window,text=convertorstr,width=10,height=1,relief=RAISED,borderwidth=10,bg="#FF4500",fg="white",
                       activeforeground="#FF4500",activebackground="white",command=maindisplay)
convertlabel.config(font=('Algerian', 40))
convertlabel.place(x=460,y=300)


window.mainloop()

